const { shape, ABILITIES, PICKUPS } = require("./simulation.cjs");
function applyAdmin(world, w, command) {
  const number = (value, min, max = Infinity) => {
    if (
      typeof value !== "number" ||
      !Number.isFinite(value) ||
      value < min ||
      value > max
    )
      throw new Error(Number.isFinite(max) ? `Enter a number from ${min} to ${max}.` : `Enter a number of at least ${min}.`);
    return value;
  };
  switch (command.action) {
    case 'reset-leaders':
      world.resetBotProfiles(false);
      break;
    case 'reset-all-profiles':
      world.resetBotProfiles(true);
      break;
    case 'reset-my-profile':
    case 'reset-my-leaders':
      w.ignoreLeaderboard=true;
      break;
    case "panel":
      w.adminPaused = false;
      w.adminOpen = command.open === true;
      w.boost = false;
      break;
    case "score": {
      const score = number(command.value, 13);
      world.setWormMass(w, score / 50);
      break;
    }
    case "add-score": {
      const score = number(command.value, 1);
      world.setWormMass(w, w.mass + score / 50);
      break;
    }
    case "power": {
      const duration = number(command.duration, 1);
      const ids =
        command.id === "all" ? ABILITIES.map(a=>a.id) : [number(command.id, 0, 6)];
      if (ids.some((id) => !Number.isInteger(id)))
        throw new Error("Choose a power-up.");
      for (const id of ids) {
        w.abilities.set(id, world.time + duration);
      }
      break;
    }
    case "clear-powers":
      w.abilities.clear();
      break;
    case "invincible":
      if (typeof command.enabled !== "boolean")
        throw new Error("Invalid invincibility value.");
      w.invincible = command.enabled;
      break;
    case "infinite-boost":
      if (typeof command.enabled !== "boolean")
        throw new Error("Invalid boost setting.");
      w.infiniteBoost = command.enabled;
      break;
    case "freeze-bots":
      if (typeof command.enabled !== "boolean")
        throw new Error("Invalid bot setting.");
      world.controls.botsFrozen = command.enabled;
      break;
    case "add-bots": {
      const count = number(command.count, 1);
      if (!Number.isSafeInteger(count))
        throw new Error("Choose a whole number of bots.");
      world.controls.botsEnabled = true;
      for (let i = 0; i < count; i++) world.spawnBot();
      break;
    }
    case "clear-bots":
      world.controls.botsEnabled = false;
      world.controls.botEpoch=(world.controls.botEpoch||0)+1;
      for (const bot of world.worms.values())
        if (bot.bot) {world.recordBot(bot);world.worms.delete(bot.id);}
      break;
    case "spawn-food":
    case "spawn-bottles": {
      const rotation =
        (world.controls.supplySequence =
          (world.controls.supplySequence || 0) + 1) * 0.7;
      const count = number(command.count ?? (command.action === "spawn-food" ? 60 : PICKUPS.length), 1),
        inner = shape(w.mass).radius + 2,
        limit = world.balance.radius - 1;
      if(!Number.isSafeInteger(count))throw new Error('Choose a whole number of supplies.');
      for (let i = 0; i < count; i++) {
        const angle = i * 2.399963229728653 + rotation,
          r = inner + Math.sqrt(i) * 0.4;
        let x = w.x + Math.cos(angle) * r,
          y = w.y + Math.sin(angle) * r;
        const distance = Math.hypot(x, y);
        if (distance > limit) {
          x *= limit / distance;
          y *= limit / distance;
        }
        world.addFood(
          { x, y },
          command.action === "spawn-food" ? 0.35 : 0.65,
          command.action === "spawn-food" ? i % 28 : PICKUPS[i % PICKUPS.length].kind,
        );
      }
      break;
    }
    case "clear-food":
      for (const food of world.food.values())
        if (Math.hypot(food.x - w.x, food.y - w.y) < 12)
          world.food.delete(food.id);
      break;
    case "reset": {
      w.abilities.clear();
      w.invincible = false;
      w.infiniteBoost = false;
      w.boost = false;
      w.angle = w.target = 0;
      w.turnVelocity = 0;
      w.x = w.y = 0;
      world.resizeWorm(w, world.balance.startingMass);
      break;
    }
    case "teleport": {
      const limit = world.balance.radius - shape(w.mass).radius - 1;
      const x = number(command.x, -limit, limit),
        y = number(command.y, -limit, limit);
      if (Math.hypot(x, y) > limit)
        throw new Error("Choose a position inside the arena.");
      const dx = x - w.x,
        dy = y - w.y;
      w.x = x;
      w.y = y;
      w.body.forEach((p) => {
        p.x += dx;
        p.y += dy;
      });
      w.adminRevision = (w.adminRevision || 0) + 1;
      break;
    }
    default:
      throw new Error("Unknown admin command.");
  }
  return {
    score: Math.floor(w.mass * 50),
    invincible: !!w.invincible,
    infiniteBoost: !!w.infiniteBoost,
    botsFrozen: world.controls.botsFrozen,
    bots: [...world.worms.values()].filter((p) => p.bot).length,
    food: world.food.size,
    paused: !!w.adminPaused,
    x: w.x,
    y: w.y,
    abilities: world.abilityState(w).map((a) => ({
      id: a.id,
      name: a.name,
      remaining: Math.ceil(a.remaining),
    })),
  };
}
module.exports = { applyAdmin };
