const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const {performance}=require('node:perf_hooks');
const { WebSocketServer, WebSocket } = require("ws");

const { createWorld, shape } = require("./simulation.cjs");
const { ids:SKIN_IDS } = require('./public/skin-catalog.js');
const { minimapPacket } = require("./minimap.cjs");
const {Packet}=require("./packet.cjs");
const {wormBounds,inNetworkView}=require('./network-view.cjs');
const {createMinimapWorker}=require('./minimap-worker.cjs');
const { applyAdmin } = require("./admin.cjs");
const { isLocalAdmin } = require("./local-access.cjs");
const { createAdminAccess } = require("./admin-access.cjs");
const { createBotScores } = require("./bot-scores.cjs");
const { createProfileResets } = require("./profile-resets.cjs");
const PORT = Number(process.env.PORT || 3000);
const ROOT = path.join(__dirname, "public");
const adminAccess=createAdminAccess(path.join(__dirname,'.data',`admin-key-${PORT}.txt`));
const profileResets=createProfileResets(path.join(__dirname,'.data',`profile-resets-${PORT}.json`));
const botScores=createBotScores(process.env.WORMATE_BOT_SCORES || path.join(__dirname,'.data',`bot-scores-${PORT}.json`),{worker:true,backup:true});
const requestedBots=Number(process.env.BOTS??300);
const world = createWorld({balance:{bots:Number.isSafeInteger(requestedBots)&&requestedBots>=0&&requestedBots<30000?requestedBots:300},botRecords:botScores.records,onBotRecord:row=>botScores.markDirty(row)});
botScores.flush();
const { worms, food, spawn, kill } = world;
const { radius: RADIUS, step: STEP } = world.balance;
const clients = new Set();
const minimaps=createMinimapWorker(packet=>{for(const c of clients)if(c.id&&c.ws.readyState===WebSocket.OPEN&&c.ws.bufferedAmount<131072)c.ws.send(packet);});
minimaps.request(worms.values(),RADIUS);
let ticks = 0;
// All numbers use the archived client's network byte order (big endian).

function sendMinimap(ws,snapshot) {
  ws.send((!minimaps.failed&&minimaps.latest)||(snapshot?(snapshot.minimap||=minimapPacket(snapshot.visible,RADIUS,shape)):minimapPacket(worms.values(),RADIUS,shape)));
}
function writePosition(p, w) {
  const abilities = world.abilityState(w);
  p.u8((w.accelerating ? 1 : 0) | 2)
    .f32(w.mass)
    .coord(w.x)
    .coord(w.y)
    .count(abilities.length);
  // The old renderer increases blinking with F, so send elapsed duration.
  abilities.forEach((a) =>
    p.u8(a.id).u8(Math.min(100, Math.floor((1 - a.fraction) * 100))),
  );
}
function worldSnapshot(){
  const visible=[...worms.values()],positions=new Map(),bounds=new Map();
  for(const w of visible)bounds.set(w.id,wormBounds(w));
  return {visible,positions,bounds};
}
function sendWorld(c,snapshot=worldSnapshot()) {
  if(c.ws.readyState!==WebSocket.OPEN)return;
  if(c.ws.bufferedAmount>4*1024*1024){c.ws.close(1013,'Connection too slow; please reconnect.');return;}
  if(c.ws.bufferedAmount>131072)return;
  const me = worms.get(c.id) || c.spectator;
  if (!me) return;
  const visible = snapshot.visible;
  const active=visible.filter(w=>w.id===me.id||inNetworkView(me,snapshot.bounds.get(w.id),world.has(me,6),c.active.has(w.id)));
  const activeIds=new Set(active.map(w=>w.id));
  const joined = visible.filter((w) => !c.known.has(w.id));
  const gone = [...c.known].filter((id) => !worms.has(id));
  const foodView = Math.max(50, 30 * shape(me.mass).radius + 20) / (world.has(me,6) ? 0.7 : 1);
  const inView = f => Math.abs(f.x-me.x) < foodView && Math.abs(f.y-me.y) < foodView;
  const newFood = food.querySquare(me.x,me.y,foodView,c.food);
  const removedFood=[];
  for(const id of c.food){const f=food.get(id);if(!f||!inView(f))removedFood.push(id);}
  // Zero artificial future offset: the archived client already interpolates.
  const p = new Packet(1).i16(0);
  p.count(newFood.length);
  newFood.forEach((f) => {
    p.i32(f.id).coord(f.size).u8(f.kind);
    c.food.add(f.id);
  });
  const eaten = removedFood.filter((id) => world.eaten.has(id));
  const expired = removedFood.filter((id) => !world.eaten.has(id));
  p.count(expired.length);
  expired.forEach((id) => p.i32(id));
  p.count(eaten.length);
  eaten.forEach((id) => p.i32(id).i16(world.eaten.get(id)));
  removedFood.forEach((id) => c.food.delete(id));
  const othersJoined = joined.filter((w) => w.id !== me.id);
  p.count(othersJoined.length);
  othersJoined.forEach((w) => {p.i16(w.id).u8(w.skin).text(w.name);c.known.add(w.id);});
  p.count(gone.length);
  gone.forEach((id) => {
    p.i16(id);
    c.known.delete(id);
    c.revisions.delete(id);
  });
  const resync = active.filter(
    (w) =>
      !c.active.has(w.id) ||
      (c.revisions.get(w.id) || 0) !== (w.adminRevision || 0),
  );
  p.count(resync.length);
  resync.forEach((w) => {
    p.i16(w.id).f32(w.mass).count(w.body.length);
    w.body.forEach((pos) => p.coord(pos.x).coord(pos.y));
    c.known.add(w.id);
    c.revisions.set(w.id, w.adminRevision || 0);
  });
  const hidden=[...c.active].filter(id=>!activeIds.has(id)&&worms.has(id)&&id!==me.id);
  p.count(hidden.length);for(const id of hidden)p.i16(id);
  c.active=activeIds;
  const position=w=>{
    let bytes=snapshot.positions.get(w.id);
    if(!bytes){const packet=new Packet(0,32);writePosition(packet,w);bytes=packet.finish().subarray(1);snapshot.positions.set(w.id,bytes);}
    return bytes;
  };
  const others = active.filter((w) => w.id !== me.id);
  p.count(others.length);
  others.forEach((w) => {
    p.i16(w.id);
    p.bytes(position(w));
  });
  p.bytes(position(me));
  p.send(c.ws);
  if (ticks % Math.round(1 / STEP) === 0) {
    if(!c.dead)c.ws.send(JSON.stringify({type:"session", score:Math.floor(me.mass*50), duration:me.age, kills:me.kills, headshots:me.headshots||0}));
    if(minimaps.failed)sendMinimap(c.ws,snapshot);
  }
  if (ticks % Math.max(1,Math.round(.25 / STEP)) === 0) {
    const ranking = snapshot.ranking||=visible.slice().sort((a,b)=>b.mass-a.mass);
    const board = new Packet(3)
      .i16(visible.length)
      .i16(ranking.findIndex((w) => w.id === me.id) + 1)
      .u8(Math.min(10, ranking.length));
    ranking.slice(0, 10).forEach((w) => board.i16(w.id).f32(w.mass * 50));
    board.send(c.ws);
    c.ws.send(JSON.stringify({type:'leaderboard',online:visible.length,rank:ranking.findIndex(w=>w.id===me.id)+1,
      rows:ranking.slice(0,10).map(w=>({id:w.id,name:w.name,skin:w.skin,score:Math.floor(w.mass*50)}))}));
  }
}
function simulationTick(){
  world.step();
  ticks = world.ticks;
  // Large score histories are saved in batches to limit sustained disk writes.
  if(ticks%Math.round(5/STEP)===0)void botScores.flushAsync();
  if(clients.size){const snapshot=worldSnapshot();for(const c of clients)sendWorld(c,snapshot);}
  for (const event of world.kills) {
    for (const c of clients) {
      if (c.id === event.killer)
        new Packet(6)
          .i16(event.victim)
          .u8(event.headshot ? 1 : 0)
          .send(c.ws);
      if (c.id === event.victim) {
        c.lastScore = event.score;
        c.dead = true;
        c.spectator = event.worm;
        c.ws.send(JSON.stringify({type:"session", final:true, score:event.score, rank:event.rank, duration:event.worm.age, kills:event.worm.kills, headshots:event.worm.headshots||0}));
        const final = new Packet(1).i16(0);
        for (let i = 0; i < 4; i++) final.count(0);
        final.count(1).i16(event.victim); // Fade the dead player using native state.
        for (let i = 0; i < 3; i++) final.count(0);
        writePosition(final, event.worm);
        final.send(c.ws);
        new Packet(5).send(c.ws);
      }
    }
    if (event.bot){
      const epoch=world.controls.botEpoch||0;
      setTimeout(() => {
        if (!simulationStopped&&world.controls.botsEnabled&&(world.controls.botEpoch||0)===epoch) world.respawnBot(event.name,event.skin);
      }, 1800).unref();
    }
  }
  if(ticks%Math.round(1/STEP)===0&&clients.size)minimaps.request(worms.values(),RADIUS);
}
let nextFrame=performance.now()+STEP*1000,simulationTimer,simulationStopped=false;
function scheduleTick(){
  if(simulationStopped)return;
  simulationTick();nextFrame+=STEP*1000;const now=performance.now();
  if(now-nextFrame>STEP*1000)nextFrame=now+1;
  simulationTimer=setTimeout(scheduleTick,Math.max(1,nextFrame-now)).unref();
}
simulationTimer=setTimeout(scheduleTick,STEP*1000).unref();

const types = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".woff": "font/woff",
  ".ico": "image/x-icon",
};
const server = http.createServer((req, res) => {
  const url = new URL(req.url, "http://localhost");
  if(adminAccess.handle(req,res,url))return;
  if(url.pathname==='/api/profile-epochs'){
    res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});
    return res.end(JSON.stringify(profileResets.epochs));
  }
  if (url.pathname === "/api/state") {
    res.writeHead(200, {
      "Content-Type": "application/json",
      "Cache-Control": "no-store",
    });
    return res.end(
      JSON.stringify({
        version: 4,
        arenaRadius: RADIUS,
        leaderboard: [...world.botRecords.values(),...[...worms.values()].filter(w=>!w.bot).map(w=>({name:w.name,highScore:w.ignoreLeaderboard?0:Math.floor(w.mass*50),kills:w.ignoreLeaderboard?0:w.kills,headshots:w.ignoreLeaderboard?0:w.headshots||0,level:1,bot:false}))].sort((a,b)=>b.highScore-a.highScore),
        ticks,
        food: food.size,
        deathFood: [...food.values()].filter((f) => f.source === "death")
          .length,
        bots: [...worms.values()].filter((w) => w.bot).length,
        botsFrozen:world.controls.botsFrozen,
        pickups: [...food.values()].filter((f) => f.kind >= 81).length,
        players: [...clients].map((c) => {
          const w = worms.get(c.id);
          return {
            id: c.id,
            dead: c.dead,
            score: w ? Math.floor(w.mass * 50) : c.lastScore,
            x: w?.x,
            y: w?.y,
            boost: w?.accelerating,
            speed: w?.speed,
            angle: w?.angle,
            infiniteBoost: !!w?.infiniteBoost,
            name: w?.name,
            skin: w?.skin,
            abilities: w ? world.abilityState(w) : [],
            kills: w?.kills,
          };
        }),
      }),
    );
  }
  let filename;
  try {
    filename = path.resolve(
      ROOT,
      "." +
        decodeURIComponent(url.pathname === "/" ? "/index.html" : url.pathname),
    );
  } catch {
    res.writeHead(400);
    return res.end();
  }
  if (!filename.startsWith(ROOT + path.sep)) {
    res.writeHead(403);
    return res.end();
  }
  fs.readFile(filename, (err, data) => {
    if (err) {
      res.writeHead(404);
      return res.end("Not found");
    }
    res.writeHead(200, {
      "Content-Type":
        types[path.extname(filename)] || "application/octet-stream",
      "Cache-Control": "no-cache",
    });
    res.end(data);
  });
});
const wss = new WebSocketServer({ server, path: "/game", maxPayload: 4096 });
wss.on("connection", (ws, request) => {
  const c = {
    ws,
    known: new Set(),
    active: new Set(),
    food: new Set(),
    revisions: new Map(),
    id: null,
    dead: false,
  };
  let sameOrigin = false;
  try {
    sameOrigin = new URL(request.headers.origin).host === request.headers.host;
  } catch {}
  clients.add(c);
  ws.on("message", (data, isBinary) => {
    if (simulationStopped) return;
    if (!isBinary) {
      try {
        const command = JSON.parse(data.toString());
        if (!(sameOrigin && isLocalAdmin(request)) && !adminAccess.valid(command.adminToken))
          throw new Error("Sign in with your private admin key to use these controls.");
        const w = worms.get(c.id);
        if (!w) throw new Error("Join a game first.");
        if (command.type !== "admin") throw new Error("Unknown command.");
        const state = applyAdmin(world, w, command);
        if(command.action==='reset-leaders'||command.action==='reset-all-profiles'){
          const scope=command.action==='reset-leaders'?'leaders':'allProfiles';
          profileResets.reset(scope);
          for(const client of clients)if(client.ws.readyState===WebSocket.OPEN)client.ws.send(JSON.stringify({type:'profile-reset',scope,epochs:profileResets.epochs}));
        }else if(command.action==='reset-my-profile'){
          ws.send(JSON.stringify({type:'profile-reset',scope:'me',epochs:profileResets.epochs}));
        }else if(command.action==='reset-my-leaders'){
          ws.send(JSON.stringify({type:'profile-reset',scope:'myLeaders',epochs:profileResets.epochs}));
        }
        botScores.flush();
        const notice={'reset-leaders':'Leaderboard scores reset.','reset-all-profiles':'All profiles reset.','reset-my-profile':'Your profile reset.','reset-my-leaders':'Your leaderboard stats reset.'}[command.action];
        ws.send(JSON.stringify({ type: "admin", ok: true, state, notice }));
      } catch (error) {
        ws.send(
          JSON.stringify({ type: "admin", ok: false, error: error.message }),
        );
      }
      return;
    }
    if (!c.id) {
      if (
        data.length < 7 ||
        data[0] !== 129 ||
        data.readInt16BE(1) !== 2400 ||
        data[3] !== 0
      )
        return ws.close(1002, "Expected 2017 guest handshake");
      const length = data[6];
      if (length > 32 || data.length !== 7 + length * 2)
        return ws.close(1002, "Invalid nickname");
      let name = "";
      for (let i = 0; i < length; i++)
        name += String.fromCharCode(data.readUInt16BE(7 + i * 2));
      const skin = data.readUInt16BE(4);
      const w = spawn(name, SKIN_IDS.includes(skin) ? skin : 0);
      c.id = w.id;
      new Packet(0).i16(w.id).f32(RADIUS).send(ws);
      sendMinimap(ws);
      sendWorld(c);
      return;
    }
    const w = worms.get(c.id);
    if (w && data.length === 6 && data[0] === 130) {
      const angle = data.readFloatBE(1);
      if (Number.isFinite(angle)) {
        w.target = Math.atan2(Math.sin(angle), Math.cos(angle));
        w.boost = !!data[5];
      }
    } else if (w && data.length === 1) {
      w.target = ((data[0] & 127) / 128) * Math.PI * 2;
      w.boost = !!(data[0] & 128);
    }
  });
  ws.on("error", () => {});
  ws.on("close", () => {
    clients.delete(c);
    const w = worms.get(c.id);
    if (w) kill(w);
  });
});
server.on("error", (error) => {
  console.error(
    error.code === "EADDRINUSE"
      ? `Port ${PORT} is already in use. Try opening http://localhost:${PORT}, or choose another PORT.`
      : error.message,
  );
  process.exit(1);
});
let stopTimer;
async function stopAfterSaving() {
  if (simulationStopped) return;
  simulationStopped = true;
  clearTimeout(simulationTimer);
  try {
    if (!await botScores.settle()) throw new Error('Pending bot scores could not be saved');
  } catch (error) {
    console.error('Shutdown deferred: ' + error.message);
    simulationStopped = false;
    nextFrame = performance.now() + STEP * 1000;
    simulationTimer = setTimeout(scheduleTick, STEP * 1000).unref();
    return;
  }
  for (const client of wss.clients) client.terminate();
  server.close();
  server.closeAllConnections();
}

if (require.main === module) {
  const stopRequest = path.join(__dirname, '.runtime', `stop-${process.pid}.request`);
  stopTimer = setInterval(() => {
    try {
      fs.unlinkSync(stopRequest);
    } catch (error) {
      if (error.code !== 'ENOENT') console.error('Could not read stop request: ' + error.message);
      return;
    }
    void stopAfterSaving();
  }, 500).unref();
  process.on('SIGINT', stopAfterSaving);
  process.on('SIGTERM', stopAfterSaving);
  server.listen(PORT, "0.0.0.0", () => {
    const url = `http://localhost:${PORT}`;
    console.log(
      `Wormate 2017 is running at ${url}\nKeep this terminal open. Press Ctrl+C to stop the server.`,
    );
    if (process.argv.includes("--open") && process.platform === "win32") {
      require("node:child_process").execFile(
        "rundll32.exe",
        ["url.dll,FileProtocolHandler", url],
        { windowsHide: true },
        () => {},
      );
    }
  });
}

server.on("close", () => {simulationStopped=true;clearTimeout(simulationTimer);clearInterval(stopTimer);minimaps.close();void botScores.close();});
module.exports = { server, wss, world, clients };
