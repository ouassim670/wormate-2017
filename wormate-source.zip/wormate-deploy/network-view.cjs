const {spineBounds} = require('./geometry.cjs');
const {shape} = require('./simulation.cjs');
function wormBounds(w) {
  const box = spineBounds(w.body), pad = 12 * shape(w.mass).radius;
  return {minX:box.minX-pad,minY:box.minY-pad,maxX:box.maxX+pad,maxY:box.maxY+pad};
}
function inNetworkView(viewer, box, zoom = false, active = false) {
  // The camera sees at most one camera radius in either axis. Keep three,
  // plus visual/body bounds and hysteresis, so turns and zoom cannot pop worms in.
  const camera = 4 + 12.5 * shape(viewer.mass).radius;
  const reach = Math.max(35, 3 * camera) / (zoom ? .7 : 1) + (active ? 12 : 0);
  return box.maxX >= viewer.x-reach && box.minX <= viewer.x+reach && box.maxY >= viewer.y-reach && box.minY <= viewer.y+reach;
}
module.exports = {wormBounds, inNetworkView};
