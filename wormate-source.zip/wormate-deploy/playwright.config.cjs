const {defineConfig} = require('@playwright/test');
module.exports = defineConfig({
  testDir: './tests', testMatch:'**/*.spec.cjs', timeout: 60000, workers: 1,
  use: {baseURL: 'http://127.0.0.1:3100', browserName:'chromium', channel:'chrome', viewport:{width:1280,height:800}},
  webServer: [
    {command:'node tests/performance-server.cjs',url:'http://127.0.0.1:3106',reuseExistingServer:false},
    {command:'node tests/giant-server.cjs',url:'http://127.0.0.1:3105',reuseExistingServer:false},
    {command:'node tests/browser-server.cjs',url:'http://127.0.0.1:3100',reuseExistingServer:false},
    {command:'node tests/fixture-server.cjs',url:'http://127.0.0.1:3101',reuseExistingServer:false},
    {command:'node tests/movement-server.cjs',url:'http://127.0.0.1:3102',reuseExistingServer:false},
    {command:'node tests/death-server.cjs',url:'http://127.0.0.1:3103',reuseExistingServer:false},
    {command:'node tests/menu-server.cjs',url:'http://127.0.0.1:3104',reuseExistingServer:false},
  ],
});
