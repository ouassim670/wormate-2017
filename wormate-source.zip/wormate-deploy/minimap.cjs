const {visibleSpine,pointDistanceSquared}=require('./geometry.cjs');

// Preserve the archived 80x80 circular bitmap protocol.
const OFFSETS=[34,29,26,24,22,20,18,17,15,14,13,12,11,10,9,8,8,7,6,6,5,5,4,4,3,3,2,2,2,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,2,2,2,3,3,4,4,5,5,6,6,7,8,8,9,10,11,12,13,14,15,17,18,20,22,24,26,29,34];
function minimapPacket(worms,arenaRadius,shape){
  const occupied=new Uint8Array(80*80),scale=40/arenaRadius;
  for(const w of worms){
    const points=visibleSpine(w.body).map(p=>({x:40+p.x*scale,y:40+p.y*scale}));
    // Half a pixel keeps tiny worms readable; physical thickness adds to it.
    const radius=.5+shape(w.mass).radius*scale,radiusSquared=radius*radius;
    for(let i=0;i<points.length;i++){
      const a=points[Math.max(0,i-1)],b=points[i];
      const px=Math.floor(b.x),py=Math.floor(b.y);
      if(px>=0&&px<80&&py>=0&&py<80)occupied[px+py*80]=1;
      const minX=Math.max(0,Math.floor(Math.min(a.x,b.x)-radius));
      const maxX=Math.min(79,Math.floor(Math.max(a.x,b.x)+radius));
      const minY=Math.max(0,Math.floor(Math.min(a.y,b.y)-radius));
      const maxY=Math.min(79,Math.floor(Math.max(a.y,b.y)+radius));
      for(let y=minY;y<=maxY;y++)for(let x=minX;x<=maxX;x++){
        if(occupied[x+y*80])continue;
        if(pointDistanceSquared({x:x+.5,y:y+.5},a,b)<=radiusSquared)occupied[x+y*80]=1;
      }
    }
  }
  const packet=Buffer.alloc(629);packet[0]=2;
  let bit=0;
  for(let y=0;y<80;y++)for(let x=OFFSETS[y];x<80-OFFSETS[y];x++){
    if(occupied[x+y*80])packet[1+(bit>>3)]|=1<<(bit&7);
    bit++;
  }
  return packet;
}
module.exports={minimapPacket,OFFSETS};
