// Only a direct loopback connection may administer the game. A tunnel also
// connects from loopback, so reject forwarded requests regardless of their Host.
function isLocalAdmin(request) {
  const address=request.socket.remoteAddress;
  if(!['127.0.0.1','::1','::ffff:127.0.0.1'].includes(address))return false;
  if(Object.keys(request.headers).some(key=>key==='forwarded'||key.startsWith('x-forwarded-')||key.startsWith('cf-')))return false;
  try {
    const host=new URL('http://'+request.headers.host).hostname;
    return ['localhost','127.0.0.1','[::1]'].includes(host);
  }catch{return false;}
}
module.exports={isLocalAdmin};
