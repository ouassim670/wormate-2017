// Same big-endian wire format as the archived client, written into one growing
// buffer instead of allocating a separate Buffer for every field.
class Packet {
  constructor(type,capacity=1024){this.buffer=Buffer.allocUnsafe(Math.max(1,capacity));this.length=0;this.u8(type);}
  reserve(bytes){
    if(this.length+bytes>this.buffer.length){
      let size=this.buffer.length;while(size<this.length+bytes)size*=2;
      const next=Buffer.allocUnsafe(size);this.buffer.copy(next,0,0,this.length);this.buffer=next;
    }
  }
  u8(v){this.reserve(1);this.buffer[this.length++]=v&255;return this;}
  i16(v){this.reserve(2);this.buffer.writeInt16BE(v,this.length);this.length+=2;return this;}
  i32(v){this.reserve(4);this.buffer.writeInt32BE(v|0,this.length);this.length+=4;return this;}
  f32(v){this.reserve(4);this.buffer.writeFloatBE(v,this.length);this.length+=4;return this;}
  count(v){
    let value=v>>>0,size=1;for(let n=value;n>=128;n>>>=7)size++;
    this.reserve(size);
    for(let i=size-1;i>=0;i--){this.buffer[this.length+i]=(value&127)|(i===size-1?0:128);value>>>=7;}
    this.length+=size;return this;
  }
  coord(v){
    const n=Math.max(0,Math.min(16777215,Math.round((v/10000+1)*8388608)));
    this.reserve(3);this.buffer[this.length++]=n>>>16;this.buffer[this.length++]=n>>>8;this.buffer[this.length++]=n;return this;
  }
  text(s){this.u8(s.length);this.reserve(s.length*2);for(let i=0;i<s.length;i++){this.buffer.writeUInt16BE(s.charCodeAt(i),this.length);this.length+=2;}return this;}
  bytes(buffer){this.reserve(buffer.length);buffer.copy(this.buffer,this.length);this.length+=buffer.length;return this;}
  finish(){return this.buffer.subarray(0,this.length);}
  send(ws){if(ws.readyState===1)ws.send(this.finish());}
}
module.exports={Packet};
