const { visibleSpine, touchesBody, sweptBodyBlocks } = require("./geometry.cjs");
const { deathFoodPositions } = require("./death-food.cjs");
const { moveWorm, turnRate } = require("./movement.cjs");
const { botName, botHeading, botBoost, botFoodScore, botFoodPriority, initialBotScore, botSkill } = require("./bots.cjs");
const { levelInfo } = require("./public/progression.js");
const { stackTail } = require("./public/tail-growth.js");
const { ids:SKIN_IDS } = require('./public/skin-catalog.js');
const {FoodMap}=require('./food-map.cjs');
const {returningBotName}=require('./bot-names.cjs');
const {SpatialGrid}=require('./spatial-grid.cjs');
function boundsOf(...paths){
  const box={minX:Infinity,minY:Infinity,maxX:-Infinity,maxY:-Infinity};
  for(const path of paths)for(let i=0;i<path.length;i++){
    const x=path[i].x,y=path[i].y;
    if(x!==x||y!==y)return {minX:-Infinity,minY:-Infinity,maxX:Infinity,maxY:Infinity};
    if(x<box.minX)box.minX=x;if(y<box.minY)box.minY=y;if(x>box.maxX)box.maxX=x;if(y>box.maxY)box.maxY=y;
  }
  if(!Object.values(box).every(Number.isFinite))return {minX:-Infinity,minY:-Infinity,maxX:Infinity,maxY:Infinity};
  return box;
}
function sweptBounds(a,b){
  const minX=Math.min(a.minX,b.minX),minY=Math.min(a.minY,b.minY),maxX=Math.max(a.maxX,b.maxX),maxY=Math.max(a.maxY,b.maxY);
  if(!Number.isFinite(minX+minY+maxX+maxY))return {minX:-Infinity,minY:-Infinity,maxX:Infinity,maxY:Infinity};
  const dx=(maxX-minX)/8+1e-8,dy=(maxY-minY)/8+1e-8;
  return {minX:minX-dx,minY:minY-dy,maxX:maxX+dx,maxY:maxY+dy};
}
function pathNearBox(a,b,box,reach){
  const pad=reach+1e-8;
  return Math.max(a.x,b.x)>=box.minX-pad&&Math.min(a.x,b.x)<=box.maxX+pad&&Math.max(a.y,b.y)>=box.minY-pad&&Math.min(a.y,b.y)<=box.maxY+pad;
}
// The renderer/protocol are recovered; server balance below is reconstruction.
const BALANCE = Object.freeze({
  // The recovered January client initializes its arena radius (yt) to 500.
  radius: 500,
  step: 0.025,
  foodCount: 62000,
  foodBorderMargin: 30,
  powerupCount: 360,
  localFoodTarget: 280,
  localPowerupTarget: 2,
  bots: 50,
  startingMass: 16 / 50,
  normalSpeed: 4,
  boostSpeed: 8,
  boostFloor: 0.25,
  boostLossPerSecond: 0.12,
  growthPerFood: 0.15,
  dropFraction: 0.55,
  dropFractionMax: 0.70,
  foodLifetime: 360,
  powerupLifetime: 90,
  magnetRange: 2.2,
  massPickupScoreMin: 50,
  massPickupScoreMax: 200,
  deathFoodLifetime: 150,
  deathFoodBudget: 6000,
  maxTurnPerSecond: 6,
  headHitRadius: 0.68,
  headHitForward: 0.18,
  bodyHitRadius: 0.56,
});
// Portion IDs and HUD indices come from the January texture dictionary.
// Effects are inferred from the icons. Durations/strengths are estimates.
const ABILITIES = Object.freeze([
  { id: 0, kind: 81, name: "Speed", duration: 50 },
  { id: 1, kind: 82, name: "Agility", duration: 40 },
  { id: 2, kind: 83, name: "Magnet", duration: 45 },
  { id: 3, kind: 84, name: "×2 food", duration: 60, multiplier: 2 },
  { id: 4, kind: 85, name: "×5 food", duration: 30, multiplier: 5 },
  { id: 5, kind: 86, name: "×10 food", duration: 20, multiplier: 10 },
  { id: 6, kind: 88, name: "Zoom", duration: 40 },
]);
const PICKUPS = Object.freeze([...ABILITIES, { kind: 87, name: "Mass" }]);
// Relative natural spawn rates; admin grants still choose the requested type.
const BOTTLE_WEIGHTS = Object.freeze([1, 1, 1, 1, 0.35, 0.15, 0.8, 0.8]);
function shape(mass) {
  const n = Math.sqrt(4 * Math.pow(5 * mass, Math.SQRT1_2) + 25),
    length = Math.min(200, Math.max(3, 5 * (n - 5) + 1));
  return {
    // Slightly faster thickness growth; spawn size and length stay intact.
    radius: 0.025 * (5 + 0.9 * n) * Math.pow(Math.max(1, mass / .32), .012),
    length: Math.floor(length),
    fraction: length - Math.floor(length),
  };
}
function deathFoodReach(mass) {
  // Richer remains attract from farther away, but avoid the old quadratic
  // explosion. Roughly 60 units at 10m score, with smooth uncapped growth.
  return .3+shape(mass).radius*2.4+45*Math.log2(1+mass/200000);
}
function createWorld(options = {}) {
  const balance = { ...BALANCE, ...options.balance },
    random = options.random || Math.random;
  const worms = new Map(),
    food = new FoodMap({lifecycle:true}),
    eaten = new Map(),
    kills = [];
  const controls = { botsFrozen: false, botsEnabled: true };
  const botRecords = options.botRecords || new Map();
  const shapeCache = new WeakMap();
  const recordCache=new WeakMap(),snapshotCache=new WeakMap(),spineCache=new WeakMap(),growthBuffers=new WeakMap(),bodyBuffers=new WeakMap();
  function wormShape(w){
    const cached=shapeCache.get(w);
    if(cached&&cached.mass===w.mass)return cached.value;
    const value=shape(w.mass);shapeCache.set(w,{mass:w.mass,value});return value;
  }
  let botSequence = 0;
  function recordBot(w) {
    if(!w.bot)return;
    const old=botRecords.get(w.name);
    const score=Math.floor(w.mass*50), peak=w.progressPeakScore ?? 16;
    const timeXP=Math.floor(w.age/10),cached=recordCache.get(w);
    if(cached&&cached.row===old&&cached.score===score&&cached.timeXP===timeXP&&cached.kills===w.kills&&cached.headshots===(w.headshots||0)&&cached.ignore===!!w.ignoreLeaderboard)return;
    const earnedScore=(old?.earnedScore||0)+Math.max(0,score-peak);
    const survivalXP=(old?.survivalXP||0)+Math.max(0,timeXP-(w.progressTimeXP||0));
    w.progressPeakScore=Math.max(score,peak);w.progressTimeXP=timeXP;
    const xp=Math.floor(earnedScore/1000)+survivalXP;
    const row={name:w.name,highScore:Math.max(old?.highScore||0,w.ignoreLeaderboard?0:score),kills:Math.max(old?.kills||0,w.ignoreLeaderboard?0:w.kills),headshots:Math.max(old?.headshots||0,w.ignoreLeaderboard?0:w.headshots||0),earnedScore,survivalXP,xp,coins:Math.floor(earnedScore/2500),level:levelInfo(xp).level,bot:true};
    if(!old || Object.keys(row).some(key=>row[key]!==old[key])) {
      botRecords.set(w.name,row);options.onBotRecord?.(row);
    }
    recordCache.set(w,{row:botRecords.get(w.name),score,timeXP,kills:w.kills,headshots:w.headshots||0,ignore:!!w.ignoreLeaderboard});
  }
  function resetBotProfiles(all=false){
    for(const [name,old] of botRecords){
      botRecords.set(name,all?{name,highScore:0,kills:0,headshots:0,earnedScore:0,survivalXP:0,xp:0,coins:0,level:1,bot:true}:{...old,highScore:0,kills:0,headshots:0});
    }
    for(const w of worms.values()){
      w.ignoreLeaderboard=true;
      if(all&&w.bot){w.progressPeakScore=Math.floor(w.mass*50);w.progressTimeXP=Math.floor(w.age/10);}
    }
    options.onBotRecord?.();
  }
  function spawnBot(name, skin, startingScore) {
    const overrides=startingScore===undefined?{}:{mass:startingScore/50,progressPeakScore:startingScore};
    return spawn(name || botName(random,[...worms.values()].map(w=>w.name),++botSequence,botRecords),skin ?? SKIN_IDS[Math.floor(random()*SKIN_IDS.length)],true,overrides);
  }
  function respawnBot(name,skin){
    // Most departures are a new person joining. Only the rare returning
    // identity can reuse its saved profile, and never while its name is active.
    const returning=returningBotName(random,name,new Set([...worms.values()].map(w=>w.name)));
    return spawnBot(returning,skin);
  }
  // Rebuild once per tick so direct admin/test edits to the food map stay valid.
  // Nearby queries keep the larger archived arena within the 25 ms tick budget.
  let foodGrid = new Map();
  function nearbyFood(x, y, reach) {
    const result = [];
    const minX=Math.floor((x-reach)/16),maxX=Math.floor((x+reach)/16),
      minY=Math.floor((y-reach)/16),maxY=Math.floor((y+reach)/16);
    // Uncapped rich-food reach can cover the arena. Visit occupied cells
    // instead of walking an arbitrarily large rectangle of empty space.
    if((maxX-minX+1)*(maxY-minY+1)>foodGrid.size){
      for(const [key,cell] of foodGrid){
        const [gx,gy]=key.split(',').map(Number);
        if(gx>=minX&&gx<=maxX&&gy>=minY&&gy<=maxY)result.push(...cell);
      }
      return result;
    }
    for (let gx = minX; gx <= maxX; gx++)
      for (let gy = minY; gy <= maxY; gy++) {
        const cell = foodGrid.get(`${gx},${gy}`);
        if (cell) result.push(...cell);
      }
    return result;
  }
  let nextId = 1,
    ticks = 0,
    time = 0;
  const point = (radius = Math.max(0,balance.radius-balance.foodBorderMargin-.05)) => {
    const a = random() * Math.PI * 2,
      r = Math.sqrt(random()) * radius;
    return { x: Math.cos(a) * r, y: Math.sin(a) * r };
  };
  function addFood(
    p = point(),
    size = 0.2 + random() * 0.25,
    kind = Math.floor(random() * 28),
    value = size * balance.growthPerFood,
  ) {
    const q = (v) =>
      Math.max(
        0,
        Math.min(65535, Math.round((v / (1.02 * balance.radius) + 1) * 32768)),
      );
    const id = (q(p.y) << 16) | q(p.x) | 0;
    if (food.has(id)) return;
    const f = food.create({
      id,
      x: ((id & 65535) / 32768 - 1) * 1.02 * balance.radius,
      y: (((id >>> 16) & 65535) / 32768 - 1) * 1.02 * balance.radius,
      size,
      kind,
      value,
      createdAt: time,
      // Stagger expiry so the initial arena never disappears all at once.
      expiresAt: time + (kind >= 81 && kind <= 88 ? balance.powerupLifetime : balance.foodLifetime) * (5 / 6 + random() / 3),
    });
    if(Math.hypot(f.x,f.y)>balance.radius-balance.foodBorderMargin)return;
    food.set(id, f);
    return f;
  }
  function spawnPosition(center, inner = 0, outer = 4) {
    const angle = random() * Math.PI * 2,
      distance = Math.sqrt(inner * inner + random() * (outer * outer - inner * inner));
    const p = {x:center.x + Math.cos(angle)*distance, y:center.y + Math.sin(angle)*distance};
    return Math.hypot(p.x,p.y) < balance.radius - balance.foodBorderMargin - .05 ? p : null;
  }
  function seedSweets(count) {
    let cluster = point(), added = 0;
    const attempts = count * 3;
    // A scattered baseline plus small patches avoids both a rigid grid and
    // uniformly isolated sweets. Attempts are bounded even if IDs coincide.
    for (let i = 0; i < attempts && added < count; i++) {
      if (i % 8 === 0) cluster = point();
      const p = random() < 0.55 ? point() : spawnPosition(cluster);
      if (p && addFood(p)) added++;
    }
    return added;
  }
  function replenish(initial = false) {
    if (balance.foodCount <= 0) return;
    let sweets = 0;
    const bottles = [], counts = PICKUPS.map(() => 0);
    for (const f of food.values()) {
      if (f.kind >= 81 && f.kind <= 88) {bottles.push(f);counts[PICKUPS.findIndex(a=>a.kind===f.kind)]++;}
      else if (f.source !== 'death') sweets++;
    }
    sweets += seedSweets(Math.min(Math.max(0,balance.foodCount-sweets),initial ? balance.foodCount : 512));
    function bottle(center, local = false) {
      if (balance.powerupCount <= 0) return false;
      let id = 0;
      if(local){
        // Nearby supplies must not guarantee a rare multiplier in every set.
        let roll=random()*BOTTLE_WEIGHTS.reduce((sum,weight)=>sum+weight,0);
        for(;id<BOTTLE_WEIGHTS.length-1;id++){
          roll-=BOTTLE_WEIGHTS[id];if(roll<0)break;
        }
      }else{
        // Maintain the weighted arena mix as bottles are eaten or expire.
        const need=counts.map((count,i)=>(count+1)/BOTTLE_WEIGHTS[i]);
        id=need.indexOf(Math.min(...need));
      }
      for (let attempt=0;attempt<20;attempt++) {
        const p = local ? spawnPosition(center,8+wormShape(center).radius,38+wormShape(center).radius) : point();
        if (!p || bottles.some(f=>Math.hypot(f.x-p.x,f.y-p.y)<5)) continue;
        // New bottles appear ahead of play, never directly inside a worm head.
        if ([...worms.values()].some(w=>Math.hypot(w.x-p.x,w.y-p.y)<wormShape(w).radius+3)) continue;
        const f=addFood(p,0.65,PICKUPS[id].kind,0);
        if(f){bottles.push(f);counts[id]++;return true;}
      }
      return false;
    }
    for(let i=0, missing=Math.min(Math.max(0,balance.powerupCount-bottles.length),initial?balance.powerupCount:12);i<missing;i++) bottle();
    if (initial) return;
    const players=[...worms.values()].filter(w=>!w.bot);
    const sweetCap=balance.foodCount+Math.min(8000,Math.max(2000,players.length*400));
    const bottleCap=balance.powerupCount+20;
    for(const w of players) {
      let nearby=nearbyFood(w.x,w.y,35).filter(f=>f.kind<81&&f.source!=='death'&&food.has(f.id)&&Math.hypot(f.x-w.x,f.y-w.y)<35).length;
      const amount=Math.min(80,Math.max(0,balance.localFoodTarget-nearby),sweetCap-sweets);
      for(let i=0;i<amount;i++) {
        const p=spawnPosition(w,5+wormShape(w).radius,34);
        if(p&&addFood(p)) sweets++;
      }
      const nearBottles=bottles.filter(f=>Math.hypot(f.x-w.x,f.y-w.y)<45).length;
      const amountBottles=Math.min(2,Math.max(0,balance.localPowerupTarget-nearBottles),bottleCap-bottles.length);
      for(let i=0;i<amountBottles;i++) bottle(w,true);
    }
  }
  function spawn(name, skin, bot = false, overrides = {}) {
    // Prefer space away from existing bodies, including the player's start lane.
    let p, bestClearance=-Infinity;
    // Build once per spawn, rather than repeatedly measuring every point for
    // each of the 100 candidate positions. Bounds only reject points that
    // cannot beat the current exact minimum; placement and tie rules stay exact.
    const placement=[...worms.values()].map(other=>{
      const chunks=[];
      for(let start=0;start<other.body.length;start+=16){
        const end=Math.min(other.body.length,start+16);let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
        for(let i=start;i<end;i++){const b=other.body[i];minX=Math.min(minX,b.x);minY=Math.min(minY,b.y);maxX=Math.max(maxX,b.x);maxY=Math.max(maxY,b.y);}
        chunks.push({start,end,minX,minY,maxX,maxY});
      }
      return {body:other.body,radius:wormShape(other).radius,box:boundsOf(other.body),chunks};
    });
    function clearanceAt(candidate){
      let clearance=Infinity;
      const cannotBeat=(box,reach)=>{
        if(reach<0)return true;
        const dx=Math.max(0,box.minX-candidate.x,candidate.x-box.maxX),dy=Math.max(0,box.minY-candidate.y,candidate.y-box.maxY);
        return dx*dx+dy*dy>reach*reach;
      };
      for(const other of placement){
        if(cannotBeat(other.box,clearance+other.radius+1e-8))continue;
        for(const chunk of other.chunks){
          if(cannotBeat(chunk,clearance+other.radius+1e-8))continue;
          for(let i=chunk.start;i<chunk.end;i++){const b=other.body[i];clearance=Math.min(clearance,Math.hypot(b.x-candidate.x,b.y-candidate.y)-other.radius);}
        }
      }
      return clearance;
    }
    const centralChance=bot ? .9 : .85,innerRadius=bot ? .4 : .48;
    for (let attempt = 0; attempt < 100; attempt++) {
      const candidate=point(balance.radius*(attempt<70&&random()<centralChance?innerRadius:.94));
      const clearance=clearanceAt(candidate);
      if(clearance>bestClearance){bestClearance=clearance;p=candidate;}
      if(clearance>12){p=candidate;break;}
    }
    const firstPlayer = !bot && ![...worms.values()].some((w) => !w.bot);
    if (
      firstPlayer &&
      [...worms.values()].every((w) =>
        w.body.every((b) => Math.hypot(b.x, b.y) > wormShape(w).radius+12),
      )
    )
      p = { x: 0, y: 0 };
    if(worms.size>=30000)throw new Error('The archived protocol has no free worm IDs.');
    while (worms.has(nextId)) {
      nextId = (nextId % 30000) + 1;
    }
    const id = nextId;
    nextId = (nextId % 30000) + 1;
    const w = {
      id,
      name: name.slice(0, 32) || "Guest",
      skin,
      bot,
      ...p,
      mass: balance.startingMass,
      angle: bot ? random() * Math.PI * 2 : 0,
      target: 0,
      boost: false,
      accelerating: false,
      age: 0,
      abilities: new Map(),
      kills: 0,
      ...overrides,
    };
    w.target = w.angle;
    w.body = initialBody(w);
    worms.set(w.id, w);
    recordBot(w);
    if (firstPlayer) {
      for (let i = 1; i < 19; i++) addFood({ x: w.x + i * 0.9, y: w.y }, 0.35);
    }
    return w;
  }
  function initialBody(w) {
    const s = wormShape(w);
    if (s.length * s.radius * 2 < 25)
      return Array.from({ length: s.length }, (_, i) => ({
        x: w.x - Math.cos(w.angle) * s.radius * i * 2,
        y: w.y - Math.sin(w.angle) * s.radius * i * 2,
      }));
    const r = Math.min(20, Math.max(4, (s.length * s.radius) / Math.PI)),
      limit = balance.radius - 2 * r - 5;
    const distance = Math.hypot(w.x, w.y);
    if (distance > limit) {
      w.x *= limit / distance;
      w.y *= limit / distance;
    }
    const cx = w.x - Math.sin(w.angle) * r,
      cy = w.y + Math.cos(w.angle) * r;
    return Array.from({ length: s.length }, (_, i) => ({
      x: cx + Math.sin(w.angle - (i * 2 * s.radius) / r) * r,
      y: cy - Math.cos(w.angle - (i * 2 * s.radius) / r) * r,
    }));
  }
  function has(w, id) {
    return (w.abilities.get(id) || 0) > time;
  }
  function abilityState(w) {
    return ABILITIES.filter((a) => has(w, a.id)).map((a) => ({
      id: a.id,
      name: a.name,
      remaining: w.abilities.get(a.id) - time,
      fraction: Math.min(1, (w.abilities.get(a.id) - time) / a.duration),
    }));
  }
  function changeMass(w, mass) {
    const oldShape=wormShape(w);
    w.mass=mass;
    const grown=shape(mass);
    // Grow from the current tail, keeping the existing path and head position.
    while(w.body.length<grown.length)w.body.push({...w.body.at(-1)});
    w.body.length=grown.length;
    if(grown.length===200&&grown.radius>oldShape.radius){
      let points=growthBuffers.get(w);
      if(!points){points=new Float64Array(400);growthBuffers.set(w,points);}
      for(let i=0;i<200;i++){points[2*i]=w.body[i].x;points[2*i+1]=w.body[i].y;}
      stackTail(points,grown.length,oldShape.radius,grown.radius);
      w.body.forEach((p,i)=>{p.x=points[2*i];p.y=points[2*i+1];});
    }
  }
  function consume(w, f) {
    if (!food.delete(f.id)) return;
    eaten.set(f.id, w.id);
    const ability = ABILITIES.find((a) => a.kind === f.kind);
    if (f.kind === 87) {
      // Instant growth uses the existing tail path, independent of food multipliers.
      const score = balance.massPickupScoreMin + Math.floor(random() * (balance.massPickupScoreMax - balance.massPickupScoreMin + 1));
      changeMass(w, w.mass + score / 50);
    } else if (ability) {
      // Refresh only this effect; distinct multipliers stack independently.
      w.abilities.set(ability.id, time + ability.duration);
    } else {
      const multiplier =
        ABILITIES.reduce(
          (product, a) => product * (a.multiplier && has(w, a.id) ? a.multiplier : 1),
          1,
        );
      changeMass(w,w.mass+f.value*multiplier);
    }
  }
  function kill(w, killer = null, headshot = false, dropFood = true, dropBudget = null) {
    recordBot(w);
    if (!worms.delete(w.id)) return;
    const drops = dropFood ? deathFoodPositions(w, wormShape(w).radius, random) : [],
      added = [];
    for (const position of drops) {
      // Quantized food IDs can coincide. Retry nearby positions so a death in
      // an existing food pile does not silently lose the dropped mass.
      for (let attempt = 0; attempt < 8; attempt++) {
        const angle = (added.length + attempt) * 2.399963229728653,
          offset = attempt * 0.015;
        let x = position.x + Math.cos(angle) * offset,
          y = position.y + Math.sin(angle) * offset;
        const d = Math.hypot(x, y),
          limit = Math.max(0,balance.radius - balance.foodBorderMargin - .05);
        if (d > limit) {
          x *= limit / d;
          y *= limit / d;
        }
        const food = addFood({ x, y }, 1, Math.floor(random() * 28), 0);
        if (food) {
          food.source = "death";
          food.expiresAt = time + balance.deathFoodLifetime * (0.8 + random() * 0.4);
          added.push(food);
          break;
        }
      }
    }
    // Preserve total nourishment independently of how many sweets are drawn.
    const dropFraction = balance.dropFraction + random() * (balance.dropFractionMax - balance.dropFraction);
    const value = (w.mass * dropFraction) / Math.max(1, added.length);
    const score=w.mass*50;
    // Small deaths leave modest sweets and a faint halo, easing into rich
    // remains above 500 score rather than abruptly changing at the threshold.
    const smallDropSize=.24+.14*Math.min(1,score/500);
    const richBlend=Math.max(0,Math.min(1,(score-500)/1500));
    for (const food of added) {
      food.value = value;
      // The archived client caps the candy sprite at 0.5, but uses the size
      // field to give rich drops the large orange/white star glow in footage.
      const richSize=Math.min(3, 0.8 + Math.sqrt(value) * 0.7);
      food.size = (smallDropSize+(richSize-smallDropSize)*richBlend) * (0.85 + random() * 0.3);
      // Tiny pieces need close contact. Only visually substantial remains get
      // the source worm's full attraction, with a smooth size-based transition.
      const attraction=Math.pow(Math.max(0,Math.min(1,(food.size-.4)/.45)),2);
      food.collectRadius=.3+(deathFoodReach(w.mass)-.3)*attraction;
    }
    const budget=dropBudget||{drops:food.deathSnapshot(),start:0};
    if(dropBudget)budget.drops.push(...added);
    const end=budget.drops.length-balance.deathFoodBudget;
    while(budget.start<end)food.delete(budget.drops[budget.start++].id);
    if (killer && worms.has(killer.id)) {
      killer.kills++;
      if (headshot) killer.headshots = (killer.headshots || 0) + 1;
    }
    kills.push({
      victim: w.id,
      killer: killer?.id,
      headshot,
      score: Math.floor(w.mass * 50),
      rank: 1 + [...worms.values()].filter((other) => other.mass > w.mass).length,
      bot: w.bot,
      name: w.name,
      skin: w.skin,
      worm: w,
    });
  }
  function moveBody(w, x, y) {
    const s = wormShape(w);
    const source=w.body;
    let body=bodyBuffers.get(w);if(!body){body=[];}
    body.length=s.length;
    for(let i=0;i<s.length;i++)if(!body[i])body[i]={x:0,y:0};
    bodyBuffers.set(w,source);w.body=body;
    let oldX=source[0].x,oldY=source[0].y;
    const distance = Math.hypot(oldX - x, oldY - y);
    if (!distance){
      for(let i=0;i<body.length;i++){const p=source[Math.min(i,source.length-1)];body[i].x=p.x;body[i].y=p.y;}
      return boundsOf(body);
    }
    const h = s.radius / (s.radius + distance);
    body[0].x=x;body[0].y=y;
    let minX=x,minY=y,maxX=x,maxY=y;
    for (let i = 1; i < body.length; i++) {
      const point=body[i],old=source[Math.min(i,source.length-1)],previousX=old.x,previousY=old.y;
      // The archived client's final point uses its fractional segment length.
      const tail = i === body.length - 1;
      const f = tail
        ? (s.fraction * s.radius) / (s.fraction * s.radius + distance)
        : h;
      point.x=body[i-1].x*(1-2*f)+(previousX+oldX)*f;
      point.y=body[i-1].y*(1-2*f)+(previousY+oldY)*f;
      minX=Math.min(minX,point.x);minY=Math.min(minY,point.y);maxX=Math.max(maxX,point.x);maxY=Math.max(maxY,point.y);
      oldX=previousX;oldY=previousY;
    }
    return Number.isFinite(minX+minY+maxX+maxY)?{minX,minY,maxX,maxY}:{minX:-Infinity,minY:-Infinity,maxX:Infinity,maxY:Infinity};
  }
  let controlBounds=new Map(),foodPriorityBounds=new WeakMap(),controlGrid,controlList;
  const controlCandidates=[],collectorCandidates=[],collisionCandidates=[];
  function steerBot(w) {
    // Short, varied reaction delays make bots less precise without changing
    // their movement limits or restricting where they can roam.
    if(time < (w.botThinkAt || 0)) return;
    const skill=botSkill(w),awareness=1.1+skill*(1.5+wormShape(w).radius*.3);
    w.botThinkAt = time + 0.16 - skill*.06 + random() * (0.12-skill*.04);
    let nearest,
      bestScore = -Infinity,bestX=Infinity,bestY=Infinity,bestIndex=Infinity,cellOrder=false;
    function considerCell(gx,gy,cell){
      const distance=Math.hypot(Math.max(0,gx*16-w.x,w.x-(gx+1)*16),Math.max(0,gy*16-w.y,w.y-(gy+1)*16));
      if(distance>64)return;
      let range=foodPriorityBounds.get(cell);
      if(range===undefined){let small=0,large=0;for(const f of cell){small=Math.max(small,botFoodPriority(f,w,0));large=Math.max(large,botFoodPriority(f,w,1));}range={small,large};foodPriorityBounds.set(cell,range);}
      // Every food priority is linear in skill. Interpolating the maxima at
      // both endpoints is an upper bound, and exact for ordinary-food cells.
      const priorityBound=range.small+(range.large-range.small)*skill+1e-12;
      if(priorityBound/(4+distance)<bestScore)return;
      for (let foodIndex=0;foodIndex<cell.length;foodIndex++) {
      const f=cell[foodIndex];
      const dx=f.x-w.x,dy=f.y-w.y,lowerDistance=Math.max(Math.abs(dx),Math.abs(dy));
      if(lowerDistance>64)continue;
      const priority=botFoodPriority(f,w,skill);
      // The real Euclidean distance cannot be smaller than this bound.
      // If even this optimistic score loses, the candidate cannot win.
      if(priority/(4+lowerDistance)<bestScore)continue;
      const distance=Math.hypot(dx,dy);if(distance>64)continue;
      const score=priority/(4+distance);
      if (score > bestScore || cellOrder&&score===bestScore&&(gx<bestX||gx===bestX&&(gy<bestY||gy===bestY&&foodIndex<bestIndex))) {
        if(!food.has(f.id))continue;
        bestScore = score;
        nearest = f;
        bestX=gx;bestY=gy;bestIndex=foodIndex;
      }
      }
    }
    // Traverse cells in the identical order as nearbyFood. Prune only cells
    // whose most optimistic score cannot beat the already selected food.
    const minX=Math.floor((w.x-64)/16),maxX=Math.floor((w.x+64)/16),minY=Math.floor((w.y-64)/16),maxY=Math.floor((w.y+64)/16);
    if((maxX-minX+1)*(maxY-minY+1)>foodGrid.size){
      for(const [key,cell] of foodGrid){const [gx,gy]=key.split(',').map(Number);if(gx>=minX&&gx<=maxX&&gy>=minY&&gy<=maxY)considerCell(gx,gy,cell);}
    }else{
      cellOrder=true;
      const centerX=Math.floor(w.x/16),centerY=Math.floor(w.y/16);
      // Strong nearby candidates let the same exact score reject distant cells.
      // Explicit tie order preserves the old x/y/insertion-order winner.
      for(let ring=0;ring<=4;ring++)for(let dx=-ring;dx<=ring;dx++)for(let dy=-ring;dy<=ring;dy++){
        if(Math.max(Math.abs(dx),Math.abs(dy))!==ring)continue;
        const gx=centerX+dx,gy=centerY+dy;
        if(gx<minX||gx>maxX||gy<minY||gy>maxY)continue;
        const cell=foodGrid.get(`${gx},${gy}`);if(cell)considerCell(gx,gy,cell);
      }
    }
    w.target = botHeading(w,nearest,time,balance.radius,random);
    if (Math.hypot(w.x, w.y) > balance.radius - 10)
      w.target = Math.atan2(-w.y, -w.x);
    for (const index of controlGrid.queryInto({minX:w.x,minY:w.y,maxX:w.x,maxY:w.y},wormShape(w).radius+awareness,controlCandidates)) {
      const other=controlList[index];
      if (other.id === w.id) continue;
      const safe = wormShape(w).radius + wormShape(other).radius + awareness;
      if(!pathNearBox(w,w,controlBounds.get(other.id),safe))continue;
      const near = other.body.find(
        (p) => Math.hypot(p.x - w.x, p.y - w.y) < safe,
      );
      if (near) {
        w.target = Math.atan2(w.y - near.y, w.x - near.x);
        break;
      }
    }
  }
  function step() {
    ticks++;
    time = ticks * balance.step;
    eaten.clear();
    kills.length = 0;
    food.expire(time);
    const deathFood=food.deathSnapshot();
    // Preserve global Map order whenever any query could use its sparse-map
    // fallback. Dense worlds use direct cell lookups and can reuse their Map.
    let maxRadius=0;for(const w of worms.values())maxRadius=Math.max(maxRadius,wormShape(w).radius);
    const maxQueryReach=Math.max(64,35,maxRadius+.3+balance.magnetRange+Math.max(balance.normalSpeed,balance.boostSpeed*1.25)*balance.step);
    const maxQueryCells=(Math.ceil(2*maxQueryReach/16)+1)**2;
    foodGrid=food.cells.size>=maxQueryCells?food.snapshotQueryGrid():food.snapshotGrid();
    controlBounds=new Map([...worms.values()].map(w=>[w.id,boundsOf(w.body)]));
    controlList=[...worms.values()];controlGrid=new SpatialGrid();
    const controlIndices=new Map();
    controlList.forEach((w,index)=>{controlIndices.set(w.id,index);controlGrid.insert(index,controlBounds.get(w.id),wormShape(w).radius);});
    const previous=new Map();
    for(const [id,w] of worms){
      let snapshot=snapshotCache.get(w);
      if(!snapshot){snapshot={};snapshotCache.set(w,snapshot);}
      snapshot.x=w.x;snapshot.y=w.y;snapshot.angle=w.angle;snapshot.mass=w.mass;snapshot.spine=null;
      snapshot.body=w.body;
      snapshot.bounds=controlBounds.get(w.id);
      previous.set(id,snapshot);
    }
    for (const w of worms.values()) {
      w.age += balance.step;
      for (const [id, expiry] of w.abilities)
        if (expiry <= time) w.abilities.delete(id);
      if (w.adminPaused || (w.bot && controls.botsFrozen)) {
        w.speed = 0;
        w.accelerating = false;
        w.turnVelocity = 0;
        continue;
      }
      if (w.bot) {
        w.boost=botBoost(w,time,balance,random);
        steerBot(w);
      }
      w.accelerating =
        w.boost && (w.mass > balance.boostFloor || w.infiniteBoost);
      w.speed =
        (w.accelerating ? balance.boostSpeed : balance.normalSpeed) *
        (w.accelerating && has(w, 0) ? 1.25 : 1);
      if (w.accelerating && !w.infiniteBoost)
        w.mass = Math.max(
          balance.boostFloor,
          w.mass - balance.boostLossPerSecond * balance.step,
        );
      const turn = turnRate(wormShape(w).radius, w.speed, balance, has(w, 1), w.mass);
      moveWorm(w, w.speed, turn, balance.step);
      controlBounds.set(w.id,moveBody(w, w.x, w.y));
      controlGrid.insert(controlIndices.get(w.id),controlBounds.get(w.id),wormShape(w).radius);
      const radius = wormShape(w).radius;
      // Ordinary pickups stay local. Resolve contested remains after all
      // movement so player order cannot decide who gets the whole trail.
      const initialReach=radius+.3+(has(w,2)?balance.magnetRange:0)+w.speed*balance.step;
      const gx0=Math.floor((w.x-initialReach)/16),gx1=Math.floor((w.x+initialReach)/16),gy0=Math.floor((w.y-initialReach)/16),gy1=Math.floor((w.y+initialReach)/16);
      let nearby=(gx1-gx0+1)*(gy1-gy0+1)>foodGrid.size
        ?nearbyFood(w.x,w.y,initialReach)
        :food.queryPickups(w.x,w.y,initialReach,initialReach+1e-8);
      const oldHead=previous.get(w.id),minPickupX=Math.min(oldHead.x,w.x),maxPickupX=Math.max(oldHead.x,w.x),minPickupY=Math.min(oldHead.y,w.y),maxPickupY=Math.max(oldHead.y,w.y);
      let pickupReach=radius+.3+(has(w,2)?balance.magnetRange:0);
      // Only expand an unboosted query if this head can actually pick up a
      // magnet now. Most worms need a much smaller local search rectangle.
      if(!has(w,2)&&(gx1-gx0+1)*(gy1-gy0+1)<=foodGrid.size&&nearby.some(f=>f.kind===83&&f.source!=='death'&&distanceToSegment(f,oldHead,w)<pickupReach))
        nearby=food.queryPickups(w.x,w.y,initialReach,radius+.3+balance.magnetRange+w.speed*balance.step+1e-8);
      for (const f of nearby) {
        if(f.source==='death')continue;
        const pad=pickupReach+1e-8;
        if(f.x<minPickupX-pad||f.x>maxPickupX+pad||f.y<minPickupY-pad||f.y>maxPickupY+pad)continue;
        if(!food.has(f.id))continue;
        // Sweep the head movement so boost cannot skip a pickup between ticks.
        if (distanceToSegment(f,oldHead,w)<pickupReach){
          consume(w,f);
          // A magnet picked up mid-loop can immediately collect later sweets.
          if(f.kind===83)pickupReach=radius+.3+balance.magnetRange;
        }
      }
      if(wormShape(w).radius>radius)controlGrid.insert(controlIndices.get(w.id),controlBounds.get(w.id),wormShape(w).radius);
    }
    const collectors=[...worms.values()]
      .filter(w=>!w.adminPaused&&!(w.bot&&controls.botsFrozen))
      .map(w=>({w,radius:wormShape(w).radius,magnet:has(w,2)}));
    const collectorGrid=new SpatialGrid();
    collectors.forEach(({w,radius,magnet},index)=>{
      const old=previous.get(w.id);
      collectorGrid.insert(index,{minX:Math.min(old.x,w.x),minY:Math.min(old.y,w.y),maxX:Math.max(old.x,w.x),maxY:Math.max(old.y,w.y)},radius+(magnet?balance.magnetRange:0));
    });
    for(const f of deathFood){
      if(!food.has(f.id))continue;
      let winner;
      for(const index of collectorGrid.queryInto({minX:f.x,minY:f.y,maxX:f.x,maxY:f.y},f.collectRadius||.3,collectorCandidates)){
        const {w,radius,magnet}=collectors[index];
        const distance=distanceToSegment(f,previous.get(w.id),w);
        const gap=Math.max(0,distance-radius);
        if(gap<(f.collectRadius||.3)+(magnet?balance.magnetRange:0)){
          // Contact with the body takes priority over remote attraction.
          // Otherwise compare surface distance, with stronger magnet pull.
          const contact=gap<=.3,priority=gap/(magnet?1.6:1);
          if(!winner||Number(contact)>Number(winner.contact)||contact===winner.contact&&(priority<winner.priority||priority===winner.priority&&(distance<winner.distance||distance===winner.distance&&w.id<winner.w.id)))winner={w,distance,contact,priority};
        }
      }
      if(!winner)continue;
      consume(winner.w,f);
    }
    // Decide deaths from the same snapshot, then apply them simultaneously.
    const deaths = new Map(),
      list = [...worms.values()];
    const spines = new Map(),bodyBlocks=new Map();
    // Tail growth resamples/clones points within the moved body's bounds.
    // Merge already computed boxes instead of rescanning both long bodies.
    const collisionBounds=new Map(list.map(w=>[w.id,sweptBounds(previous.get(w.id).bounds,controlBounds.get(w.id))]));
    const collisionGrid=new SpatialGrid();
    list.forEach((w,index)=>{
      const radius=wormShape(w).radius,oldRadius=shape(previous.get(w.id).mass).radius;
      collisionGrid.insert(index,collisionBounds.get(w.id),Math.max(radius*balance.bodyHitRadius,radius*balance.headHitRadius+Math.max(radius,oldRadius)*balance.headHitForward));
    });
    function currentSpine(w){if(!spines.has(w.id)){let buffer=spineCache.get(w);if(!buffer){buffer=[];spineCache.set(w,buffer);}spines.set(w.id,visibleSpine(w.body,buffer));}return spines.get(w.id);}
    function oldSpine(w){const old=previous.get(w.id);return old.spine||=visibleSpine(old.body,old.spineBuffer||=[]);}
    function collisionBlocks(w){if(!bodyBlocks.has(w.id))bodyBlocks.set(w.id,sweptBodyBlocks(currentSpine(w),oldSpine(w)));return bodyBlocks.get(w.id);}
    const heads=new Map(list.map(w=>[w.id,{
      from:headHitCenter(previous.get(w.id),balance),to:headHitCenter(w,balance),
    }]));
    for (const w of list) {
      if (w.adminPaused) continue;
      const headPath=heads.get(w.id),headRadius=wormShape(w).radius*balance.headHitRadius;
      if (Math.max(Math.hypot(headPath.from.x,headPath.from.y),Math.hypot(headPath.to.x,headPath.to.y))+headRadius >= balance.radius) {
        if (w.invincible) {
          // The old collision phase sampled all bodies before wall clamping.
          // Freeze this lazy sample before the in-place translation as well.
          currentSpine(w);
          if(w.body===previous.get(w.id).body)moveBody(w,w.x,w.y);
          const limit = Math.max(0,balance.radius - wormShape(w).radius*(balance.headHitRadius+balance.headHitForward) - 0.1),
            d = Math.hypot(w.x, w.y);
          const x = (w.x * limit) / d,
            y = (w.y * limit) / d,
            dx = x - w.x,
            dy = y - w.y;
          w.body.forEach((p) => {
            p.x += dx;
            p.y += dy;
          });
          w.x = x;
          w.y = y;
          w.angle = w.target = Math.atan2(-y, -x);
          w.adminRevision = (w.adminRevision || 0) + 1;
          continue;
        }
        deaths.set(w.id, { w, border:true });
        continue;
      }
      if (w.age < 3 || w.invincible) continue;
      const head=headPath;
      const headBox={minX:Math.min(head.from.x,head.to.x),minY:Math.min(head.from.y,head.to.y),maxX:Math.max(head.from.x,head.to.x),maxY:Math.max(head.from.y,head.to.y)};
      for (const index of collisionGrid.queryInto(headBox,headRadius,collisionCandidates)) {
        const other=list[index];
        if (w.id === other.id || other.age < 3) continue;
        const reach =
          headRadius + wormShape(other).radius * balance.bodyHitRadius;
        const headReach =
          headRadius + wormShape(other).radius * balance.headHitRadius;
        const otherHead=heads.get(other.id);
        const headDistance = movingHeadDistance(head.from,head.to,otherHead.from,otherHead.to);
        if (headDistance < headReach) {
          // Resolve border priority at first contact, before fast heads cross
          // and swap places. Equal radial positions retain the size tie-break.
          const borderAdvantage = headBorderAdvantage(head.from,head.to,otherHead.from,otherHead.to,headReach);
          const ratio = w.mass / other.mass;
          if (borderAdvantage < -1e-6 || (Math.abs(borderAdvantage) <= 1e-6 && ratio <= 1.1))
            deaths.set(w.id, {
              w,
              killer: borderAdvantage < -1e-6 || ratio < 1 / 1.1 ? other : null,
              headshot: true,
            });
          continue;
        }
        if (pathNearBox(head.from,head.to,collisionBounds.get(other.id),reach)&&touchesBody(head.from,head.to,currentSpine(other),reach,oldSpine(other),collisionBlocks(other))) {
          deaths.set(w.id, { w, killer: other });
        }
        if (deaths.has(w.id)) break;
      }
    }
    const dropBudget=deaths.size?{drops:food.deathSnapshot().slice(),start:0}:null;
    for (const d of deaths.values()) kill(d.w, d.killer, d.headshot, !d.border,dropBudget);
    for (const w of worms.values()) recordBot(w);
    if (ticks % Math.max(1,Math.round(1 / balance.step)) === 0) replenish();
  }
  if (options.populate !== false) {
    replenish(true);
    for (let i = 0; i < balance.bots; i++) spawnBot(undefined,undefined,initialBotScore(random));
  }
  return {
    balance,
    worms,
    food,
    eaten,
    kills,
    spawn,
    spawnBot,
    respawnBot,
    botRecords,
    recordBot,
    resetBotProfiles,
    addFood,
    consume,
    kill,
    step,
    has,
    abilityState,
    controls,
    setWormMass(w,mass){
      changeMass(w,mass);
      w.adminRevision=(w.adminRevision||0)+1;
    },
    resizeWorm(w, mass) {
      w.mass = mass;
      w.body = initialBody(w);
      w.adminRevision = (w.adminRevision || 0) + 1;
    },
    point,
    get ticks() {
      return ticks;
    },
    get time() {
      return time;
    },
  };
}
function distanceToSegment(p, a, b) {
  const dx = b.x - a.x,
    dy = b.y - a.y,
    length = dx * dx + dy * dy;
  const t = length
    ? Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / length))
    : 0;
  return Math.hypot(p.x - a.x - t * dx, p.y - a.y - t * dy);
}
function movingHeadDistance(a, b, c, d) {
  return distanceToSegment(
    { x: 0, y: 0 },
    { x: a.x - c.x, y: a.y - c.y },
    { x: b.x - d.x, y: b.y - d.y },
  );
}
function headHitCenter(w,balance) {
  const forward=shape(w.mass).radius*balance.headHitForward;
  return {x:w.x+Math.cos(w.angle)*forward,y:w.y+Math.sin(w.angle)*forward};
}
function headBorderAdvantage(a,b,c,d,reach) {
  const x=a.x-c.x,y=a.y-c.y,
    dx=(b.x-a.x)-(d.x-c.x),dy=(b.y-a.y)-(d.y-c.y),
    aa=dx*dx+dy*dy,bb=2*(x*dx+y*dy),cc=x*x+y*y-reach*reach;
  const t=cc<=0||aa===0 ? 0 : Math.max(0,Math.min(1,(-bb-Math.sqrt(Math.max(0,bb*bb-4*aa*cc)))/(2*aa)));
  return Math.hypot(a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t)-Math.hypot(c.x+(d.x-c.x)*t,c.y+(d.y-c.y)*t);
}
module.exports = { BALANCE, ABILITIES, PICKUPS, shape, deathFoodReach, createWorld };
