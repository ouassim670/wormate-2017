const wrap = (angle) => Math.atan2(Math.sin(angle), Math.cos(angle));
function turnRate(radius, speed, balance, agility = false, mass = 0) {
  if (speed <= 0 || balance.maxTurnPerSecond <= 0) return 0;
  // Gentle size scaling keeps grown worms steerable instead of locking them
  // into the very broad arcs produced by linear body-width scaling.
  const baseRadius = Math.max(1,balance.normalSpeed) / balance.maxTurnPerSecond;
  // Above 500,000 score, add weight gradually: 40% wider at 1M, 80% at 2M.
  // The continuous curve avoids a sudden handling change at the threshold.
  const growth = Math.log2(Math.max(1, mass / 10000));
  // Ease the high-score penalty smoothly after 2M; by 5M this is about 14%
  // easier to steer, while retaining the established 500k–2M handling.
  const heavyFactor = 1 + 0.4 * Math.min(growth,2) + 0.15 * Math.max(0,growth-2);
  // Wider normal arcs, with extra outward travel as boost speed increases.
  const boostFactor=1+.65*Math.max(0,speed/Math.max(.001,balance.normalSpeed)-1);
  const turningRadius = 1.2 * baseRadius * Math.max(1, 1.1 * Math.sqrt(radius / 0.3)) * heavyFactor * boostFactor;
  return speed / turningRadius * (agility ? 2 : 1);
}
function moveWorm(w, speed, maxTurn, dt) {
  let error = wrap(w.target - w.angle);
  // Retain the chosen turn direction when the pointer crosses directly behind
  // the head; tiny input changes there must not flip a U-turn back and forth.
  if (Math.abs(error) > Math.PI - 0.04 && Math.abs(w.turnVelocity || 0) > 0.1)
    error = Math.sign(w.turnVelocity) * Math.abs(error);
  // Respond on this tick, including reversals, without angular inertia or a
  // soft easing zone that makes small aim corrections feel disconnected.
  const omega = Math.sign(error) * Math.min(Math.abs(error) / dt, maxTurn);
  const start = w.angle,
    end = start + omega * dt;
  // Integrate an arc, rather than turning first and then stepping in a straight
  // line. This avoids polygonal corners at the fixed simulation rate.
  if (Math.abs(omega) > 0.00001) {
    w.x += (speed / omega) * (Math.sin(end) - Math.sin(start));
    w.y += (speed / omega) * (Math.cos(start) - Math.cos(end));
  } else {
    w.x += Math.cos(start) * speed * dt;
    w.y += Math.sin(start) * speed * dt;
  }
  w.angle = wrap(end);
  w.turnVelocity = omega;
}
module.exports = { moveWorm, turnRate };
