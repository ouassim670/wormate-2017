// A deterministic, lazily generated pool: no 100,000-element array or fake
// leaderboard records are needed at server startup.
const words=text=>Object.freeze(text.trim().split(/\s+/).slice(0,100));
const PREFIXES=words(`Swift Silent Shadow Dark Light Lucky Crazy Happy Angry Lazy Tiny Mighty Epic Cool Frost Silver Golden Royal Wild Blue Red Green Pink Purple Neon Mystic Cosmic Lunar Solar Star Night Dawn Dusk Storm Thunder Lightning Fire Ice Snow Winter Summer Autumn Spring Crystal Diamond Iron Steel Velvet Noble Brave Fierce Fearless Gentle Clever Sneaky Speedy Rapid Quick Slow Fuzzy Fluffy Sleepy Hungry Sweet Sour Sugar Candy Gummy Jelly Spicy Salty Toxic Venom Rebel Rogue Savage Ancient Hidden Secret Magic Phantom Ghost Ninja Pirate Viking Samurai Turbo Ultra Mega Mini Super Hyper Wicked Chaos Dream Cloud Rain Moon Sun Ocean River Forest Desert Arctic Polar`);
const NOUNS=words(`Wolf Fox Tiger Lion Bear Panda Koala Otter Lynx Falcon Eagle Raven Hawk Owl Dragon Phoenix Turtle Viper Cobra Python Mamba Snake Worm Shark Whale Orca Dolphin Kraken Spider Scorpion Gecko Frog Bunny Badger Ferret Hamster Mouse Raccoon Penguin Seal Moose Deer Leopard Panther Jaguar Cheetah Puma Cougar Sloth Lemur Gorilla Monkey Alpaca Llama Goat Horse Pony Zebra Rhino Hippo Giraffe Hyena Jackal Coyote Husky Corgi Shiba Cupcake Cookie Donut Brownie Muffin Waffle Pancake Nugget Noodle Mochi Jellybean Marshmallow Biscuit Popcorn Peanut Pickle Potato Mango Kiwi Coconut Churro Macaron Truffle Pudding Toffee Caramel Cinnamon Taffy Pretzel Gumball Icecream Lollipop Sprinkles Blueberry Strawberry Raspberry Watermelon Honeybee Firefly Dragonfly`);
const BASE_HANDLES=words(`Alex Liam Noah Lucas Leo Max Ben Jake Jack Ryan Adam Josh Tyler Luke Dylan Ethan Owen Mason James Daniel David Oliver Harry Tom Luca Finn Felix Jonas Leon Niko Nico Miko Mika Kira Luna Mia Emma Eva Sofia Anna Maya Nina Sara Alice Ruby Rose Ivy Zoe Ella Lily Jade Aria Zara Roxy Kai Sam Ash Ace Zen Rex Zero Noob Guest Nobody Cookie Mochi Toast Bubbles Noodles Potato Pickle Peanut Biscuit Muffin Donut Panda Turtle Jelly Waffle Gummy Tofu Mango Kiwi Choco Coco Sugar Yummy Sweety Wiggles Noodlez Snoopy Casper Dizzy Sunny Sparky Squishy Nomnom Ramen Boba Nugget Pudding Marshmallow`);
const NUMBERS=Object.freeze([2,3,5,7,8,9,10,11,12,13,15,17,18,19,20,21,22,23,24,25,27,28,30,31,33,42,44,47,50,55,64,66,69,70,71,77,80,88,90,95,99,100,101,111,123,144,150,171,187,199,200,202,222,247,300,333,360,404,420,444,500,555,666,777,888,999,1000,1337,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017]);
const TAGS=Object.freeze('BR PL TR RU UA FR DE ES UK US PH ID VN TH NL IT PT CZ RO HU MX AR CL IN'.split(' '));
for(const list of [PREFIXES,NOUNS,BASE_HANDLES])if(list.length!==100||new Set(list).size!==100)throw Error('Name vocabulary must contain 100 distinct entries');
const NAME_COUNT=100000,RETURN_CHANCE=.03;
function nameAt(index){
  if(!Number.isInteger(index)||index<0||index>=NAME_COUNT)throw RangeError('Invalid bot name index');
  if(index<90000){
    const pair=index%10000,style=Math.floor(index/10000),prefix=PREFIXES[Math.floor(pair/100)],noun=NOUNS[pair%100],base=prefix+noun;
    switch(style){
      case 0:return base;
      case 1:return base.toLowerCase();
      case 2:return prefix.toLowerCase()+'_'+noun.toLowerCase();
      case 3:return prefix+' '+noun;
      case 4:return base+String(7+(pair*37)%993);
      case 5:return '['+TAGS[pair%TAGS.length]+'] '+base;
      case 6:return 'x'+base+'x';
      case 7:return base+'ツ';
      case 8:return base.toUpperCase();
    }
  }
  const offset=index-90000,handle=BASE_HANDLES[Math.floor(offset/100)],style=offset%100;
  if(style>=20)return (style%2?handle.toLowerCase():handle)+NUMBERS[style-20];
  switch(style){
    case 0:return handle;
    case 1:return handle.toLowerCase();
    case 2:return handle+'_';
    case 3:return '_'+handle;
    case 4:return handle+'ツ';
    case 5:return handle+'.exe';
    case 6:return handle+'YT';
    case 7:return handle+'GG';
    case 8:return '['+TAGS[Math.floor(offset/100)%TAGS.length]+'] '+handle;
    case 9:return 'x'+handle+'x';
    case 10:return 'im'+handle;
    case 11:return 'its'+handle;
    case 12:return handle+' :)';
    case 13:return handle+'XD';
    case 14:return handle+'_x';
    case 15:return handle+'!';
    case 16:return handle+'?';
    case 17:return handle+'V2';
    case 18:return handle+' <3';
    case 19:return handle+'_io';
  }
}
function botName(random,names,sequence=0,history){
  const used=names instanceof Set?names:new Set(names);
  const unavailable=name=>used.has(name)||!!history?.has(name);
  const offset=Math.min(NAME_COUNT-1,Math.max(0,Math.floor(random()*NAME_COUNT)));
  // 7919 is coprime to 100,000. Bounded probes stay inexpensive even after a
  // long session has retired most of the pool or a deterministic RNG repeats.
  for(let attempt=0;attempt<128;attempt++){
    const name=nameAt((offset+attempt*7919)%NAME_COUNT);
    if(!unavailable(name))return name;
  }
  const base=nameAt(offset).slice(0,22);
  let suffix=Math.max(0,sequence);
  while(unavailable(base+'_'+suffix.toString(36)))suffix++;
  return base+'_'+suffix.toString(36);
}
function returningBotName(random,name,activeNames){
  return typeof name==='string'&&name.length>0&&random()<RETURN_CHANCE&&!activeNames.has(name)?name:undefined;
}
module.exports={BASE_HANDLES,NAME_COUNT,RETURN_CHANCE,nameAt,botName,returningBotName};
