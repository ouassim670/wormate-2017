const path=require('node:path'),{Worker}=require('node:worker_threads');
function createWorkerStore(file,base,{now=Date.now,onError=error=>console.warn(`Bot score save delayed (${error.code||error.message}); retrying.`),backup=false}={}){
  const worker=new Worker(path.join(__dirname,'bot-score-writer.cjs'),{workerData:{file,backup}});worker.unref();
  let changed=new Map(),full=false,pending=null,flight=null,sequence=0,retryAt=0,failed=false,closed=false,reported=false;
  const dirty=()=>full||changed.size>0;
  function restore(message){if(message.full)full=true;else for(const row of message.rows)if(!changed.has(row.name))changed.set(row.name,row);}
  function finish(ok,error){
    if(!flight)return;
    const {message,resolve}=flight;flight=null;pending=null;
    if(!ok){restore(message);retryAt=now()+250;if(!reported){reported=true;onError(error||Error('Score writer retry'));}}
    else{retryAt=0;reported=false;}
    worker.unref();resolve(ok);
  }
  worker.on('message',message=>{if(flight&&message.id===flight.message.id)finish(message.ok,message.error?Object.assign(Error(message.error),{code:message.error}):undefined);});
  worker.on('error',error=>{failed=true;finish(false,error);});
  worker.on('exit',code=>{if(!closed){failed=true;finish(false,Error('Score writer exited ('+code+')'));}});
  const store={records:base.records,
    markDirty(row){if(row&&typeof row.name==='string')changed.set(row.name,row);else full=true;},
    flush(){void store.flushAsync();return false;},
    flushAsync(){
      if(pending)return pending;
      if(closed||!dirty()||now()<retryAt)return Promise.resolve(false);
      if(failed){
        base.markDirty();changed.clear();full=false;
        pending=base.flushAsync().then(ok=>{pending=null;if(!ok)full=true;return ok;});return pending;
      }
      const message={id:++sequence,full,rows:full?[...base.records.values()]:[...changed.values()]};
      changed=new Map();full=false;
      pending=new Promise(resolve=>{flight={message,resolve};});
      const result=pending;worker.ref();
      try{worker.postMessage(message);}catch(error){failed=true;finish(false,error);}
      return result;
    },
    async settle(){
      if(pending)await pending;
      if(dirty()){retryAt=0;await store.flushAsync();}
      if(pending)await pending;
      return !dirty();
    },
    async close(){const saved=await store.settle();closed=true;await worker.terminate();return saved;},
  };
  return store;
}
module.exports={createWorkerStore};
