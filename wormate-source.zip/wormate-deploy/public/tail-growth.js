(function (root) {
  // Once length reaches 200 controls, growth increases their spacing instead.
  // Keep the existing tail position: redistribute controls along the old curve
  // and let the surplus overlap there until forward movement pulls them out.
  const cappedN=(200-1)/5+5;
  const cappedMass=Math.pow((cappedN*cappedN-25)/4,Math.SQRT2)/5;
  const cappedRadius=.025*(5+.9*cappedN)*Math.pow(cappedMass/.32,-.003);
  function stackTail(points, length, oldRadius, radius) {
    const stretch = radius / Math.max(oldRadius, cappedRadius);
    if (length !== 200 || oldRadius <= 0 || stretch <= 1) return;
    // stretch > 1 means each source index is at or ahead of its destination.
    // Ascending writes therefore keep every source intact without copying.
    for (let i = 1; i < length; i++) {
      const at = Math.min(length - 1, i * stretch);
      const a = Math.floor(at), b = Math.min(length - 1, a + 1), f = at - a;
      points[2 * i] = points[2 * a] + (points[2 * b] - points[2 * a]) * f;
      points[2 * i + 1] = points[2 * a + 1] + (points[2 * b + 1] - points[2 * a + 1]) * f;
    }
  }
  if (typeof module === 'object' && module.exports) module.exports = { stackTail };
  else root.wormateStackTail = stackTail;
})(typeof window === 'undefined' ? globalThis : window);
