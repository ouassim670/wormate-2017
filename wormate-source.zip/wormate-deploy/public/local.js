const $ = id => document.getElementById(id);
let pointer = {x:innerWidth,y:innerHeight/2}, pressing=false, keys=new Set(), socket, active=false, ready=false, steeringAngle=0, phase='menu', connectionTimer, deathTimer;
function hideDeathScreen(){clearTimeout(deathTimer);$('result').hidden=true;$('result').classList.remove('death-fade');}
const status = text => {$('status').textContent=text;};
// Keep the renderer on its original WebSocket transport; remember it for Leave.
const OriginalSocket = window.WebSocket;
window.WebSocket = class extends OriginalSocket {
  constructor(url) {
    super(url);socket=this;
    this.addEventListener('message',event=>{
      if(typeof event.data!=='string')return;
      event.stopImmediatePropagation();
      try{const message=JSON.parse(event.data);if(message.type==='leaderboard'){window.wormateSetLeaderboard?.(message);return;}}catch{}
      try{const message=JSON.parse(event.data);if(message.type==='admin')dispatchEvent(new CustomEvent('wormate:admin',{detail:message}));if(message.type==='session')dispatchEvent(new CustomEvent('wormate:session',{detail:message}));if(message.type==='profile-reset')dispatchEvent(new CustomEvent('wormate:profile-reset',{detail:message}));}catch{}
    });
    this.addEventListener('close',()=>{if(this===socket&&(active||phase==='connecting'))showMenu('Connection closed. You can play again.');});
  }
};
function showMenu(message='Local server ready · choose a skin and play') {
  window.wormateUI?.finish();
  active=false;phase='menu';pressing=false;keys.clear();clearTimeout(connectionTimer);hideDeathScreen();
  socket=null;game[8]();
  window.closeLocalAdmin?.();
  document.body.classList.remove('playing');
  $('game').style.display='none';$('menu').hidden=false;$('result').hidden=true;
  $('play').disabled=!ready;$('play').textContent=ready?'Play':'Loading original assets…';status(message.includes('ready')?'':message);
  window.dispatchEvent(new Event('resize'));
}
function leave() {showMenu();}
const game = _Game(
  callback => callback(`${location.protocol==='https:'?'wss':'ws'}://${location.host}/game`),
  $('game'),$('background'),$('preview'),
  key => key==='index.game.leader.top10' ? 'Top 10' : key,
  [
    () => {ready=true;$('play').disabled=false;$('play').textContent='Play';status('');},
    () => {active=true;phase='playing';clearTimeout(connectionTimer);hideDeathScreen();document.body.classList.add('playing');$('menu').hidden=true;$('game').style.display='block';window.dispatchEvent(new Event('resize'));dispatchEvent(new Event('wormate:joined'));},
    (dead, result) => {
      if(dead){
        window.wormateUI?.finish(result);active=false;phase='dying';pressing=false;keys.clear();clearTimeout(connectionTimer);hideDeathScreen();window.closeLocalAdmin?.();
        $('score').textContent=result[0];
        deathTimer=setTimeout(()=>{if(phase!=='dying')return;phase='dead';$('result').classList.add('death-fade');$('result').hidden=false;},3000);
      }
      else showMenu('Could not connect. Check that the local server is running.');
    },
    callback => {
      const dx=pointer.x-innerWidth/2,dy=pointer.y-innerHeight/2;
      if(!window.localAdminOpen&&active&&Math.hypot(dx,dy)>4)steeringAngle=Math.atan2(dy,dx);
      callback(steeringAngle,active&&!window.localAdminOpen&&(pressing||keys.size>0));
    }
  ]
);
$('previous').onclick=()=>game[4]();$('next').onclick=()=>game[3]();
try {$('nickname').value=localStorage.getItem('nickname')||'';game[2](Number(localStorage.getItem('skin')||0));}catch{}
$('play-form').onsubmit=event=>{
  event.preventDefault();if(!ready||phase!=='menu')return;
  phase='connecting';$('play').disabled=true;$('play').textContent='Connecting…';hideDeathScreen();
  // A click on the menu must not steer the newly spawned worm back toward it.
  steeringAngle=0;pointer={x:innerWidth,y:innerHeight/2};
  try{localStorage.setItem('nickname',$('nickname').value);localStorage.setItem('skin',game[1]());}catch{}
  // Canvas layout must exist when the native client calculates its viewport.
  $('game').style.display='block';window.dispatchEvent(new Event('resize'));
  status('Connecting to the local arena…');
  if(!game[5]($('nickname').value||'Guest','guest')){showMenu('Ready to play again.');return;}
  connectionTimer=setTimeout(()=>{if(phase==='connecting')showMenu('Connection timed out. Try again.');},10000);
};
$('again').onclick=()=>{$('result').hidden=true;leave();};
$('quality').onchange=()=>game[7]($('quality').checked?1:0);
addEventListener('mousemove',e=>{if(!window.localAdminOpen)pointer={x:e.clientX,y:e.clientY};});
$('game').addEventListener('mousedown',()=>pressing=true);
addEventListener('mouseup',()=>pressing=false);
addEventListener('keydown',e=>{if(active&&['Space','ShiftLeft','ShiftRight'].includes(e.code)){e.preventDefault();keys.add(e.code);}});
addEventListener('keyup',e=>keys.delete(e.code));
addEventListener('blur',()=>{pressing=false;keys.clear();});
$('game').addEventListener('contextmenu',e=>e.preventDefault());
$('game').addEventListener('touchmove',e=>{e.preventDefault();pointer={x:e.touches[0].clientX,y:e.touches[0].clientY};pressing=e.touches.length>1;},{passive:false});
$('game').addEventListener('touchstart',e=>{pointer={x:e.touches[0].clientX,y:e.touches[0].clientY};pressing=e.touches.length>1;},{passive:true});
$('game').addEventListener('touchend',()=>pressing=false);
// A missing archive texture would otherwise leave the old loader waiting forever.
setTimeout(()=>{if(!ready)status('An original asset failed to load. Check the server terminal and reload.');},12000);
