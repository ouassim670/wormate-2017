// Atlas crops and continuous flag motifs, using the original disc shading.
// Native rendering still controls eyes, body overlap, rotation and glow.
window.wormateFlagSkins=function(sprites,skins){
  const pixels=new Map(),derived=new Map(),registered=[];
  function read(cell){
    if(!pixels.has(cell)){
      const sprite=sprites['Sheet'+cell],canvas=document.createElement('canvas');canvas.width=canvas.height=64;
      const ctx=canvas.getContext('2d');ctx.drawImage(sprite.b,sprite.c,sprite.d,64,64,0,0,64,64);
      pixels.set(cell,ctx.getImageData(0,0,64,64).data);
    }
    return pixels.get(cell);
  }
  function frame(spec){
    if(typeof spec==='number')return sprites['Sheet'+spec];
    const key=JSON.stringify(spec);if(derived.has(key))return derived.get(key);
    if(spec.flag){
      const canvas=document.createElement('canvas');canvas.width=canvas.height=64;
      const ctx=canvas.getContext('2d'),period=spec.flag==='canada'?192:160;
      ctx.fillStyle='#ed3439';ctx.fillRect(0,0,64,64);
      function polygon(points){ctx.beginPath();points.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();ctx.fill();}
      function star(x,y,r,angle=-Math.PI/2){
        polygon(Array.from({length:10},(_,i)=>{const a=angle+i*Math.PI/5,s=i%2?r*.382:r;return [x+Math.cos(a)*s,y+Math.sin(a)*s];}));
      }
      for(let repeat=-2;repeat<=2;repeat++){
        ctx.save();ctx.translate(32+spec.phase*16+repeat*period,0);
        if(spec.flag==='canada'){
          ctx.fillStyle='#ffffff';ctx.fillRect(-48,0,96,64);
          ctx.fillStyle='#ed3439';ctx.translate(0,29);
          // Complete symmetric maple leaf with a central stem and side lobes.
          polygon([[0,-24],[-5,-13],[-10,-16],[-8,-2],[-18,-8],[-17,0],[-24,3],[-10,15],[-12,21],[-2,18],[-2,29],[2,29],[2,18],[12,21],[10,15],[24,3],[17,0],[18,-8],[8,-2],[10,-16],[5,-13]]);
        }else{
          ctx.fillStyle='#ffde00';star(-35,22,12);
          for(const [x,y] of [[-15,9],[-5,18],[-5,31],[-15,41]])star(x,y,4.3,Math.atan2(22-y,-35-x));
        }
        ctx.restore();
      }
      const image=ctx.getImageData(0,0,64,64),white=read(434);
      for(let p=0;p<image.data.length;p+=4){for(let c=0;c<3;c++)image.data[p+c]=image.data[p+c]*white[p+c]/255;image.data[p+3]=white[p+3];}
      ctx.putImageData(image,0,0);
      const sprite={b:canvas,c:0,d:0,e:64,f:64};derived.set(key,sprite);return sprite;
    }
    const source=read(spec.cell),base=read(spec.background),white=read(434);
    const canvas=document.createElement('canvas');canvas.width=canvas.height=64;
    const ctx=canvas.getContext('2d'),image=ctx.createImageData(64,64);image.data.set(base);
    // Remove source-disc shading before moving the motif, then apply shading
    // at its destination. Shifting a shaded circle directly creates seams.
    for(let y=0;y<64;y++)for(let x=0;x<64;x++){
      const sx=x-spec.offset;if(sx<0||sx>=64)continue;
      const a=(y*64+sx)*4,b=(y*64+x)*4;
      if(!white[a+3]||!source[a+3])continue;
      const coverage=Math.min(1,source[a+3]/white[a+3]);
      for(let c=0;c<3;c++)image.data[b+c]=base[b+c]*(1-coverage)+source[a+c]/Math.max(1,white[a+c])*white[b+c]*coverage;
    }
    ctx.putImageData(image,0,0);
    const sprite={b:canvas,c:0,d:0,e:64,f:64};derived.set(key,sprite);return sprite;
  }
  for(const skin of window.WormateSkinCatalog.skins){
    const frames=skin.frames.map(frame);
    if(frames.some(frame=>!frame)||!sprites[skin.glow])throw Error('Missing sprite for '+skin.name);
    let glow=sprites[skin.glow];
    if(skin.glowAlpha!==undefined){
      const canvas=document.createElement('canvas');canvas.width=canvas.height=16;
      const ctx=canvas.getContext('2d');ctx.globalAlpha=skin.glowAlpha;
      ctx.drawImage(glow.b,glow.c,glow.d,glow.e,glow.f,0,0,16,16);
      glow={b:canvas,c:0,d:0,e:16,f:16};
    }
    const entry={i:skin.prime,j:frames,k:[glow]};
    if(skin.face!==undefined)entry.face=frame(skin.face);
    skins.g(skin.id,entry);registered.push({id:skin.id,name:skin.name,frames,glow});
  }
  if(typeof window.wormateObserveSkins==='function')window.wormateObserveSkins(registered,frame(434));
};
