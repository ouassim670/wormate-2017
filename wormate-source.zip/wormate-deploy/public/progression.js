(function(root){
  const levelInfo = xp => {
    xp=Math.max(0,Number(xp)||0);
    const level=Math.floor((1+Math.sqrt(1+8*xp/3000))/2);
    const start=3000*(level-1)*level/2;
    return {level,current:xp-start,required:3000*level};
  };
  const rewards = (score,seconds=0) => {
    const earned=Math.max(0,score-16);
    return {coins:Math.floor(earned/2500),xp:Math.floor(earned/1000)+Math.floor(Math.max(0,seconds)/10)};
  };
  // Convert legacy XP units once. Current XP is retained as earned while the
  // shared level thresholds now require 3,000 XP increments.
  const migrateProfile = saved => ({...saved,xp:Math.max(0,Number(saved?.xp)||0)*(saved?.progressionVersion===2?1:10),progressionVersion:2});
  const api={levelInfo,rewards,migrateProfile};
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.WormateProgression=api;
})(typeof window==='undefined'?globalThis:window);
