const adminPanel = $("admin-panel");
let localAdminAllowed = false;
let adminToken;
fetch('/api/access').then(r=>r.json()).then(access=>{localAdminAllowed=access.admin===true;adminToken=access.adminToken;}).catch(()=>{});
const adminLogin=$('admin-login');
adminLogin.addEventListener('close',()=>{window.localAdminOpen=!adminPanel.hidden;$('admin-key').value='';});
$('admin-login-cancel').onclick=()=>adminLogin.close();
$('admin-login-form').onsubmit=async event=>{
  event.preventDefault();$('admin-sign-in').disabled=true;$('admin-login-message').textContent='Signing in…';
  try{
    const response=await fetch('/api/admin/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:$('admin-key').value.trim()})});
    const result=await response.json();if(!response.ok)throw Error(result.error||'Sign in failed.');
    adminToken=result.adminToken;localAdminAllowed=true;adminLogin.close();toggleLocalAdmin(true);
  }catch(error){$('admin-login-message').textContent=error.message;}
  finally{$('admin-sign-in').disabled=false;}
};
function sendAdmin(command) {
  if (!active || !socket || socket.readyState !== WebSocket.OPEN) {
    $("admin-message").textContent = "Join a game to use these controls.";
    return;
  }
  socket.send(JSON.stringify({ type: "admin", ...command, adminToken }));
}
function toggleLocalAdmin(open = adminPanel.hidden) {
  if(open&&!localAdminAllowed){window.localAdminOpen=true;pressing=false;keys.clear();$('admin-login-message').textContent='';if(!adminLogin.open)adminLogin.showModal();return;}
  adminPanel.hidden = !open;
  window.localAdminOpen = open;
  pressing = false;
  keys.clear();
  $("admin-controls").disabled = !active;
  if (active) {
    sendAdmin({ action: "panel", open });
  } else $("admin-message").textContent = "Join a game to use these controls.";
  if (open) $("admin-close").focus();
  else document.activeElement?.blur();
}
window.closeLocalAdmin = () => {
  if(adminLogin.open)adminLogin.close();
  if (!adminPanel.hidden) toggleLocalAdmin(false);
};
addEventListener("wormate:joined", () => {
  if (!adminPanel.hidden) {
    $("admin-controls").disabled = false;
    sendAdmin({ action: "panel", open: true });
  }
});
addEventListener(
  "keydown",
  (event) => {
    if (event.code === "F2") {
      event.preventDefault();
      event.stopImmediatePropagation();
      if (!event.repeat){if(adminLogin.open)adminLogin.close();else toggleLocalAdmin();}
      return;
    }
    if (!adminPanel.hidden || adminLogin.open) {
      if (event.code === "Escape") {
        event.preventDefault();
        if(adminLogin.open)adminLogin.close();else toggleLocalAdmin(false);
      }
      event.stopImmediatePropagation();
    }
  },
  true,
);
$("admin-close").onclick = () => toggleLocalAdmin(false);
$("admin-set-score").onclick = () =>
  sendAdmin({ action: "score", value: Number($("admin-score").value) });
adminPanel.querySelectorAll("[data-add-score]").forEach(
  (button) =>
    (button.onclick = () =>
      sendAdmin({
        action: "add-score",
        value: Number(button.dataset.addScore),
      })),
);
$("admin-god").onchange = () =>
  sendAdmin({ action: "invincible", enabled: $("admin-god").checked });
$("admin-infinite-boost").onchange = () =>
  sendAdmin({
    action: "infinite-boost",
    enabled: $("admin-infinite-boost").checked,
  });
$("admin-freeze-bots").onchange = () =>
  sendAdmin({ action: "freeze-bots", enabled: $("admin-freeze-bots").checked });
$("admin-add-bots").onclick = () => sendAdmin({ action: "add-bots", count: Number($("admin-bot-count").value) });
$("admin-clear-bots").onclick = () => sendAdmin({ action: "clear-bots" });
$("admin-spawn-food").onclick = () => sendAdmin({ action: "spawn-food", count: Number($("admin-food-count").value) });
$("admin-spawn-bottles").onclick = () => sendAdmin({ action: "spawn-bottles", count: Number($("admin-bottle-count").value) });
$("admin-clear-food").onclick = () => sendAdmin({ action: "clear-food" });
$("admin-reset-player").onclick = () => sendAdmin({ action: "reset" });
$("admin-reset-leaders").onclick = () => sendAdmin({action:'reset-leaders'});
$("admin-reset-my-leaders").onclick = () => sendAdmin({action:'reset-my-leaders'});
$("admin-reset-profile").onclick = () => sendAdmin({action:'reset-my-profile'});
$("admin-reset-all-profiles").onclick = () => sendAdmin({action:'reset-all-profiles'});
$("admin-hitboxes").onchange = () =>
  (window.localHitboxes = $("admin-hitboxes").checked);
$("admin-zoom").oninput = () => {
  window.localCameraZoom = Number($("admin-zoom").value) / 100;
  $("admin-zoom-value").textContent = $("admin-zoom").value + "%";
};
$("admin-reset-view").onclick = () => {
  window.localCameraZoom = 1;
  window.localHitboxes = false;
  $("admin-zoom").value = 100;
  $("admin-zoom-value").textContent = "100%";
  $("admin-hitboxes").checked = false;
};
window.wormateDrawDebug = (ctx, worms) => {
  if (!window.localHitboxes) return;
  ctx.save();
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  for (const worm of worms) {
    if (!worm.J || !worm.z) continue;
    const count = 4 * worm.ja - 3,
      p = worm.P;
    ctx.strokeStyle = "rgba(80,255,170,.25)";
    ctx.lineWidth = 2 * worm.ga * 0.56;
    ctx.beginPath();
    ctx.moveTo(p[6], p[7]);
    for (let i = 3; i < count; i++) ctx.lineTo(p[i * 3], p[i * 3 + 1]);
    ctx.stroke();
    ctx.strokeStyle = "#afffce";
    ctx.lineWidth = 0.025;
    ctx.beginPath();
    ctx.arc(p[0]+Math.cos(p[2])*worm.ga*.15,p[1]+Math.sin(p[2])*worm.ga*.15,worm.ga*.44,0,Math.PI*2);
    ctx.stroke();
  }
  ctx.restore();
};
$("admin-give-power").onclick = () =>
  sendAdmin({
    action: "power",
    id:
      $("admin-power").value === "all" ? "all" : Number($("admin-power").value),
    duration: Number($("admin-duration").value),
  });
$("admin-clear-power").onclick = () => sendAdmin({ action: "clear-powers" });
$("admin-teleport").onclick = () =>
  sendAdmin({
    action: "teleport",
    x: Number($("admin-x").value),
    y: Number($("admin-y").value),
  });
$("admin-center").onclick = () => sendAdmin({ action: "teleport", x: 0, y: 0 });
addEventListener("wormate:admin", (event) => {
  const message = event.detail;
  if (!message.ok) {
    $("admin-message").textContent = message.error;
    return;
  }
  const state = message.state;
  $("admin-message").textContent =
    `${message.notice ? message.notice+' ' : ''}Score ${state.score.toLocaleString()} · ${state.paused ? "Paused" : "Playing"}`;
  $("admin-god").checked = state.invincible;
  $("admin-infinite-boost").checked = state.infiniteBoost;
  $("admin-freeze-bots").checked = state.botsFrozen;
  $("admin-arena-state").textContent =
    `${state.bots} bots · ${state.food} food pieces`;
  $("admin-effects").textContent =
    state.abilities.map((a) => `${a.name} ${a.remaining}s`).join(" · ") ||
    "No active powers";
});
