(() => {
  const storageKey = 'wormate-local-profile-v1';
  const fresh = () => ({coins:0,xp:0,progressionVersion:2,highScore:0,bestSurvival:0,kills:0,headshots:0,games:0,totalTime:0,registered:new Date().toISOString()});
  let profile = fresh(), round = null, sort = 'level', requestGeneration = 0;
  try { profile = {...profile, ...WormateProgression.migrateProfile(JSON.parse(localStorage.getItem(storageKey) || '{}'))}; } catch {}
  const save = () => {try {localStorage.setItem(storageKey,JSON.stringify(profile));} catch {}};
  const name = () => $('nickname').value.trim() || 'Guest';
  const levelInfo = () => WormateProgression.levelInfo(profile.xp);
  let resetEpochs={allProfiles:0,leaders:0};
  try{resetEpochs={...resetEpochs,...JSON.parse(localStorage.getItem('wormate-profile-epochs')||'{}')};}catch{}
  function resetOwnProfile(notifyTabs=false){
    profile=fresh();
    if(round){round.ignoreRewards=true;round.ignoreLeaderboard=true;}
    save();renderProfile();
    if(notifyTabs)try{localStorage.setItem('wormate-personal-reset',String(Date.now()));}catch{}
  }
  function resetOwnLeaders(notifyTabs=false){
    profile.highScore=profile.kills=profile.headshots=0;
    if(round)round.ignoreLeaderboard=true;
    save();renderProfile();
    if(notifyTabs)try{localStorage.setItem('wormate-personal-leaders-reset',String(Date.now()));}catch{}
  }
  function applyResetEpochs(epochs){
    if((epochs.allProfiles||0)>resetEpochs.allProfiles){
      resetEpochs.allProfiles=epochs.allProfiles;resetOwnProfile();
    }
    if((epochs.leaders||0)>resetEpochs.leaders){
      resetEpochs.leaders=epochs.leaders;
      profile.highScore=profile.kills=profile.headshots=0;
      if(round)round.ignoreLeaderboard=true;
      save();renderProfile();
    }
    try{localStorage.setItem('wormate-profile-epochs',JSON.stringify(resetEpochs));}catch{}
  }
  async function syncResets(){
    try{const response=await fetch('/api/profile-epochs');if(response.ok)applyResetEpochs(await response.json());}catch{}
  }
  addEventListener('wormate:profile-reset',event=>{
    applyResetEpochs(event.detail.epochs);
    if(event.detail.scope==='me')resetOwnProfile(true);
    if(event.detail.scope==='myLeaders')resetOwnLeaders(true);
  });
  addEventListener('storage',event=>{
    if(event.key==='wormate-personal-reset')resetOwnProfile();
    else if(event.key==='wormate-personal-leaders-reset')resetOwnLeaders();
    else if(event.key===storageKey){try{profile={...fresh(),...WormateProgression.migrateProfile(JSON.parse(event.newValue||'{}'))};renderProfile();}catch{}}
  });
  const duration = seconds => {
    seconds = Math.max(0,Math.floor(seconds));
    const hours = Math.floor(seconds/3600), minutes = Math.floor(seconds/60)%60;
    return `${hours ? `${hours} hours ` : ''}${minutes} min ${seconds%60} sec`;
  };
  function renderProfile() {
    const info = levelInfo();
    const values = {name:name(),coins:profile.coins.toLocaleString('en-US').replaceAll(',',''),level:info.level,xp:`${info.current} / ${info.required}`};
    document.querySelectorAll('[data-profile]').forEach(el => el.textContent=values[el.dataset.profile]);
    document.querySelectorAll('.progress i').forEach(el => el.style.width=`${100*info.current/info.required}%`);
    const rows = [
      ['High Score:',profile.highScore],['Best Survival Time:',duration(profile.bestSurvival)],
      ['Kills:',profile.kills],['Headshots:',profile.headshots],['Games Played:',profile.games],
      ['Total Play Time:',duration(profile.totalTime)],
      ['Registration Date:',new Date(profile.registered).toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric'})]
    ];
    $('profile-stats').replaceChildren(...rows.map(([label,value])=>{
      const row=document.createElement('div'), term=document.createElement('dt'), desc=document.createElement('dd');
      term.textContent=label;desc.textContent=value;row.append(term,desc);return row;
    }));
  }
  function resize() {
    document.documentElement.style.setProperty('--menu-scale',Math.min(1,(innerWidth-24)/680,(innerHeight-55)/550));
    document.documentElement.style.setProperty('--account-scale',Math.min(1,(innerWidth-16)/1120,(innerHeight-24)/690));
    document.documentElement.style.setProperty('--result-scale',Math.min(1,(innerWidth-20)/550,(innerHeight-24)/440));
  }
  const ordinal = number => {
    const n=Math.max(1,Math.floor(number||1)),tail=n%100;
    return `${n}${tail>=11&&tail<=13?'th':({1:'st',2:'nd',3:'rd'}[n%10]||'th')}`;
  };
  window.wormateUI = {
    finish(result) {
      if(!round) return;
      const final = round.latest || {};
      const score = result ? Number(result[0]) : final.score || 0;
      const seconds = final.duration ?? (performance.now()-round.started)/1000;
      if(!round.ignoreLeaderboard){
        profile.highScore=Math.max(profile.highScore,round.bestScore,score);
        profile.kills+=final.kills||0;profile.headshots+=final.headshots||0;
      }
      if(!round.ignoreRewards){
        profile.bestSurvival=Math.max(profile.bestSurvival,seconds);
        profile.totalTime+=seconds;
        const reward=WormateProgression.rewards(Math.max(round.bestScore,score),seconds);
        profile.coins+=reward.coins;profile.xp+=reward.xp;
      }
      if(result) $('final-place').textContent=ordinal(final.rank||result[1]);
      round=null;save();renderProfile();
    }
  };
  addEventListener('wormate:joined',()=>{
    round={started:performance.now(),latest:null,bestScore:0};profile.games++;save();renderProfile();
  });
  addEventListener('wormate:session',event=>{
    if(!round)return;
    round.latest=event.detail;
    round.bestScore=Math.max(round.bestScore,event.detail.score||0);
  });
  addEventListener('pagehide',()=>window.wormateUI.finish());
  $('nickname').addEventListener('input',renderProfile);
  function closePanel() {
    $('account-panel').hidden=true;$('menu').style.visibility='';requestGeneration++;
  }
  async function renderLeaders() {
    await syncResets();
    const generation=++requestGeneration;
    try {
      const response=await fetch('/api/state');if(!response.ok)throw Error();
      const state=await response.json();if(generation!==requestGeneration)return;
      const rows=[...(state.leaderboard||[])];
      const personal={name:name(),level:levelInfo().level,highScore:profile.highScore,kills:profile.kills,headshots:profile.headshots};
      const own=rows.find(row=>!row.bot&&row.name===name());
      if(own)Object.assign(own,{level:personal.level,highScore:Math.max(own.highScore,personal.highScore),kills:Math.max(own.kills,personal.kills),headshots:Math.max(own.headshots,personal.headshots)});
      else rows.push(personal);
      rows.sort((a,b)=>(b[sort]-a[sort]) || b.highScore-a.highScore);
      $('leader-rows').replaceChildren(...rows.map((row,index)=>{
        const tr=document.createElement('tr');
        [index+1,row.name,row.level,row.highScore,`${row.headshots} / ${row.kills}`].forEach((value,column)=>{
          const td=document.createElement('td');
          if(column===1){const img=document.createElement('img');img.src='/images/guest-avatar.png';img.alt='';td.append(img,document.createTextNode(value));}
          else td.textContent=value;
          if(column===3){td.title=String(value);td.style.fontSize=Math.min(25,300/String(value).length)+'px';}
          tr.append(td);
        });return tr;
      }));
      $('leaders-status').textContent='Local leaders · saved bot records and your profile';
    }catch{if(generation===requestGeneration)$('leaders-status').textContent='Could not load local leaders. Try opening this tab again.';}
  }
  function openPanel(tab) {
    $('account-panel').hidden=false;$('menu').style.visibility='hidden';
    document.querySelectorAll('[data-tab]').forEach(button=>button.setAttribute('aria-selected',button.dataset.tab===tab));
    for(const id of ['profile','leaders','settings']) $(id+'-panel').hidden=id!==tab;
    renderProfile();if(tab==='leaders')renderLeaders();else requestGeneration++;
  }
  $('open-profile').onclick=()=>openPanel('profile');
  $('leaders').onclick=()=>openPanel('leaders');$('settings').onclick=()=>openPanel('settings');
  document.querySelectorAll('[data-tab]').forEach(button=>button.onclick=()=>openPanel(button.dataset.tab));
  document.querySelectorAll('[data-sort]').forEach(button=>button.onclick=()=>{
    sort=button.dataset.sort;document.querySelectorAll('[data-sort]').forEach(el=>el.setAttribute('aria-pressed',el===button));renderLeaders();
  });
  setInterval(()=>{if(!$('account-panel').hidden&&!$('leaders-panel').hidden)renderLeaders();},3000);
  $('account-close').onclick=closePanel;
  $('logout').onclick=()=>{$('nickname').value='';try{localStorage.removeItem('nickname');}catch{}renderProfile();closePanel();};
  $('home').onclick=closePanel;
  $('language').onclick=()=>{$('language-choice').hidden=!$('language-choice').hidden;};
  $('privacy').onclick=()=>$('privacy-dialog').showModal();$('privacy-close').onclick=()=>$('privacy-dialog').close();
  try{$('quality').checked=localStorage.getItem('wormate-low-quality')==='true';}catch{}
  game[7]($('quality').checked?1:0);
  $('quality').addEventListener('change',()=>{try{localStorage.setItem('wormate-low-quality',$('quality').checked);}catch{}});
  addEventListener('keydown',event=>{if(event.code==='Escape'&&!$('account-panel').hidden){event.preventDefault();closePanel();}});
  addEventListener('resize',resize);resize();save();renderProfile();syncResets();
  setInterval(syncResets,5000);
})();
