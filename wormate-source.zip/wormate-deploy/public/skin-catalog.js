(function(root){
  // Keep the original 35 skins and the four established classic solid colours.
  // IDs remain unchanged for saved profiles and the native multiplayer protocol.
  const api={skins:[],ids:Array.from({length:39},(_,id)=>id)};
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.WormateSkinCatalog=api;
})(typeof window==='undefined'?globalThis:window);
