// Centerline samples used by the January client's st.na renderer, before its
// temporal interpolation. Collision tests follow the solid body, not its glow.
function spineBounds(...bodies) {
  let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
  for(const body of bodies)for(const p of body){minX=Math.min(minX,p.x);minY=Math.min(minY,p.y);maxX=Math.max(maxX,p.x);maxY=Math.max(maxY,p.y);}
  // All spline coefficient sets sum to one, and their negative weights total
  // at most 1/8. This bounds every sample without constructing the spline.
  if(![minX,minY,maxX,maxY].every(Number.isFinite))return {minX:-Infinity,minY:-Infinity,maxX:Infinity,maxY:Infinity};
  const dx=(maxX-minX)/8+1e-8,dy=(maxY-minY)/8+1e-8;
  return {minX:minX-dx,minY:minY-dy,maxX:maxX+dx,maxY:maxY+dy};
}
function visibleSpine(body, output) {
  const points=output||[];let cursor=0;
  function put(x,y,source){
    if(output){let p=points[cursor];if(!p)points[cursor]={x,y};else{p.x=x;p.y=y;}cursor++;}
    else{points.push(source?{...source}:{x,y});cursor++;}
  }
  if(body.length<3){for(const p of body)put(p.x,p.y,p);points.length=cursor;return points;}
  put(body[0].x,body[0].y,body[0]);
  function sample(start, weights) {
    let x=0,y=0;
    for(let i=0;i<weights.length;i++){
      const p=body[start+i],weight=weights[i];x+=weight*p.x;y+=weight*p.y;
    }
    put(x,y);
  }
  sample(0, SPINE_WEIGHTS[0]);
  sample(0, SPINE_WEIGHTS[1]);
  sample(0, SPINE_WEIGHTS[2]);
  for (let i = 0; i < body.length - 3; i++) {
    put(body[i+1].x,body[i+1].y,body[i+1]);
    sample(i, SPINE_WEIGHTS[3]);
    sample(i, SPINE_WEIGHTS[4]);
    sample(i, SPINE_WEIGHTS[5]);
  }
  const i = body.length - 3;
  put(body[i+1].x,body[i+1].y,body[i+1]);
  sample(i, SPINE_WEIGHTS[6]);
  sample(i, SPINE_WEIGHTS[7]);
  sample(i, SPINE_WEIGHTS[8]);
  put(body.at(-1).x,body.at(-1).y,body.at(-1));
  points.length=cursor;
  return points;
}
const SPINE_WEIGHTS=[
  [.7265625,.296875,-.0234375],[.4375,.625,-.0625],[.1796875,.890625,-.0703125],
  [-.0703125,.8671875,.2265625,-.0234375],[-.0625,.5625,.5625,-.0625],[-.0234375,.2265625,.8671875,-.0703125],
  [-.0703125,.890625,.1796875],[-.0625,.625,.4375],[-.0234375,.296875,.7265625],
];
function pointDistanceSquared(p, a, b) {
  const dx = b.x - a.x,
    dy = b.y - a.y,
    length = dx * dx + dy * dy;
  const t = length
    ? Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / length))
    : 0;
  return (p.x - a.x - t * dx) ** 2 + (p.y - a.y - t * dy) ** 2;
}
function segmentDistanceSquared(a, b, c, d) {
  const cross = (p, q, r) =>
    (q.x - p.x) * (r.y - p.y) - (q.y - p.y) * (r.x - p.x);
  const abC = cross(a, b, c),
    abD = cross(a, b, d),
    cdA = cross(c, d, a),
    cdB = cross(c, d, b);
  // Non-collinear intersections; collinear/zero-length edges use distances.
  if (
    abC * abD <= 0 &&
    cdA * cdB <= 0 &&
    (abC !== 0 || abD !== 0) &&
    (cdA !== 0 || cdB !== 0)
  )
    return 0;
  return Math.min(
    pointDistanceSquared(a, c, d),
    pointDistanceSquared(b, c, d),
    pointDistanceSquared(c, a, b),
    pointDistanceSquared(d, a, b),
  );
}
function unitRoots(coefficients) {
  const c=[...coefficients],scale=Math.max(...c.map(Math.abs));
  if(!scale)return [];
  while(c.length>1&&Math.abs(c.at(-1))<scale*1e-14)c.pop();
  if(c.length===1)return [];
  const value=t=>c.reduceRight((sum,n)=>sum*t+n,0);
  const critical=unitRoots(c.slice(1).map((n,i)=>n*(i+1)));
  const knots=[0,...critical.filter(t=>t>0&&t<1),1].sort((a,b)=>a-b),roots=[];
  for(const t of knots)if(Math.abs(value(t))<scale*1e-12)roots.push(t);
  for(let i=1;i<knots.length;i++){
    let lo=knots[i-1],hi=knots[i],left=value(lo),right=value(hi);
    if(left*right>=0)continue;
    for(let j=0;j<48;j++){
      const mid=(lo+hi)/2,at=value(mid);
      if((left<0)===(at<0)){lo=mid;left=at;}else hi=mid;
    }
    roots.push((lo+hi)/2);
  }
  return roots;
}
// Minimum distance over one shared time interval, with the head and both
// segment endpoints moving linearly between physics snapshots. Testing a
// spatial sweep against only the final body confuses contacts at different times.
function movingPointSegmentDistanceSquared(p0,p1,a0,b0,a1,b1){
  const rx=a0.x-p0.x,ry=a0.y-p0.y,
    vx=a1.x-p1.x-rx,vy=a1.y-p1.y-ry,
    sx=b0.x-a0.x,sy=b0.y-a0.y,
    ux=b1.x-a1.x-sx,uy=b1.y-a1.y-sy;
  const c0=rx*sy-ry*sx,c1=vx*sy-vy*sx+rx*uy-ry*ux,c2=vx*uy-vy*ux;
  const d0=sx*sx+sy*sy,d1=2*(sx*ux+sy*uy),d2=ux*ux+uy*uy;
  const times=[0,1,...unitRoots([c0,c1,c2]),...unitRoots([
    2*c1*d0-c0*d1,
    4*c2*d0+c1*d1-2*c0*d2,
    3*c2*d1,
    2*c2*d2,
  ])];
  for(const [x,y,dx,dy] of [[rx,ry,vx,vy],[rx+sx,ry+sy,vx+ux,vy+uy]]){
    const length=dx*dx+dy*dy;
    if(length)times.push(Math.max(0,Math.min(1,-(x*dx+y*dy)/length)));
  }
  let minimum=Infinity;
  for(const t of times){
    const r={x:rx+vx*t,y:ry+vy*t},s={x:r.x+sx+ux*t,y:r.y+sy+uy*t};
    minimum=Math.min(minimum,pointDistanceSquared({x:0,y:0},r,s));
  }
  return minimum;
}
// Immutable for the collision phase: reuse these swept segment bounds across
// all heads testing the same long worm, including rapid growth and stacked tails.
function sweptBodyBlocks(spine,previousSpine=spine){
  const count=Math.max(spine.length,previousSpine.length);if(count<64)return null;
  const blocks=[];
  for(let start=3;start<count;start+=32){
    const end=Math.min(count,start+32);let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
    for(let i=start-1;i<end;i++){
      const a=spine[Math.min(i,spine.length-1)],b=previousSpine[Math.min(i,previousSpine.length-1)];
      minX=Math.min(minX,a.x,b.x);minY=Math.min(minY,a.y,b.y);maxX=Math.max(maxX,a.x,b.x);maxY=Math.max(maxY,a.y,b.y);
    }
    blocks.push({start,end,minX,minY,maxX,maxY});
  }
  return blocks;
}
function touchesBody(from, to, spine, reach, previousSpine = spine, blocks=null) {
  const minX = Math.min(from.x, to.x) - reach,
    maxX = Math.max(from.x, to.x) + reach;
  const minY = Math.min(from.y, to.y) - reach,
    maxY = Math.max(from.y, to.y) + reach;
  // The first three subsegments belong to the separately tested head.
  for (let i = 3; i < Math.max(spine.length,previousSpine.length); i++) {
    if(blocks&&(i-3)%32===0){
      const block=blocks[(i-3)/32];
      if(block.maxX<minX||block.minX>maxX||block.maxY<minY||block.minY>maxY){i=block.end-1;continue;}
    }
    const a = spine[Math.min(i-1,spine.length-1)],
      b = spine[Math.min(i,spine.length-1)],
      oldA = previousSpine[Math.min(i-1,previousSpine.length-1)],
      oldB = previousSpine[Math.min(i,previousSpine.length-1)];
    if (
      Math.max(a.x, b.x, oldA.x, oldB.x) < minX ||
      Math.min(a.x, b.x, oldA.x, oldB.x) > maxX ||
      Math.max(a.y, b.y, oldA.y, oldB.y) < minY ||
      Math.min(a.y, b.y, oldA.y, oldB.y) > maxY
    )
      continue;
    const stationary=a.x===oldA.x&&a.y===oldA.y&&b.x===oldB.x&&b.y===oldB.y;
    const distance=stationary?segmentDistanceSquared(from,to,a,b):movingPointSegmentDistanceSquared(from,to,oldA,oldB,a,b);
    if (distance < reach * reach) return true;
  }
  return false;
}
module.exports = {
  spineBounds,
  visibleSpine,
  sweptBodyBlocks,
  pointDistanceSquared,
  segmentDistanceSquared,
  touchesBody,
  movingPointSegmentDistanceSquared,
};
