const fs=require('node:fs');
const path=require('node:path');
const {levelInfo}=require('./public/progression.js');
function readScores(file) {
  const rows=JSON.parse(fs.readFileSync(file,'utf8'));
  if(!Array.isArray(rows)||rows.some(row=>!row||typeof row.name!=='string'||!Number.isFinite(row.highScore))) {
    throw new Error('Invalid leaderboard rows');
  }
  return new Map(rows.map(row=>[row.name,{...row,level:levelInfo(row.xp||0).level,bot:true}]));
}
function createBotScores(file,{io=fs,now=Date.now,onError=error=>console.warn(`Bot score save delayed (${error.code}); retrying.`),worker=false,backup=false}={}) {
  const backupFile=file+'.bak';
  let records=new Map();
  let recovered=false;
  if(fs.existsSync(file)||(backup&&fs.existsSync(backupFile))) {
    try{records=readScores(file);}
    catch{
      try{
        if(!backup)throw new Error();
        records=readScores(backupFile);recovered=true;
      }catch{throw new Error('Invalid or unreadable bot leaderboard: '+file);}
      console.warn('Recovered bot leaderboard from '+backupFile);
    }
  }
  let nextBackup=0;
  let dirty=false,retryAt=0,reported=false,revision=0,pending=null;
  const store={records,markDirty(){dirty=true;revision++;},flush({checkpoint=false}={}){
    if(!dirty||pending||now()<retryAt)return false;
    const temporary=file+'.tmp';
    try{
      io.mkdirSync(path.dirname(file),{recursive:true});
      const content=JSON.stringify([...records.values()]);
      io.writeFileSync(temporary,content,{flush:true});
      io.renameSync(temporary,file);
      if(backup&&(checkpoint||now()>=nextBackup)){
        io.writeFileSync(backupFile+'.tmp',content,{flush:true});
        io.renameSync(backupFile+'.tmp',backupFile);
        nextBackup=now()+60000;
      }
      dirty=false;retryAt=0;reported=false;return true;
    }catch(error){
      if(!['EPERM','EACCES','EBUSY'].includes(error.code))throw error;
      // Windows scanners/backups can briefly lock an atomic-rename target.
      // Keep the last complete save and dirty records; retry on a later tick.
      retryAt=now()+250;
      if(!reported){reported=true;onError(error);}
      return false;
    }
  },flushAsync(){
    if(!io.promises)return Promise.resolve(store.flush());
    if(!dirty||pending||now()<retryAt)return pending||Promise.resolve(false);
    const savedRevision=revision,content=JSON.stringify([...records.values()]),temporary=file+'.tmp';
    pending=(async()=>{
      try{
        await io.promises.mkdir(path.dirname(file),{recursive:true});
        await io.promises.writeFile(temporary,content,{flush:true});
        await io.promises.rename(temporary,file);
        if(backup&&now()>=nextBackup){
          await io.promises.writeFile(backupFile+'.tmp',content,{flush:true});
          await io.promises.rename(backupFile+'.tmp',backupFile);
          nextBackup=now()+60000;
        }
        if(revision===savedRevision)dirty=false;
        retryAt=0;reported=false;return true;
      }catch(error){
        retryAt=now()+250;
        if(!reported){reported=true;onError(error);}
        return false;
      }finally{pending=null;}
    })();
    return pending;
  },async settle(){
    if(pending)await pending;
    return store.flush();
  }};
  if(recovered)store.markDirty();
  if(!worker||io!==fs)return store;
  const workerStore=require('./bot-score-worker-store.cjs').createWorkerStore(file,store,{now,onError,backup});
  if(recovered)workerStore.markDirty();
  return workerStore;
}
module.exports={createBotScores};
