// Shared prototype accessors keep food objects on a stable, fast shape. A
// per-object defineProperty here makes every hot food lookup much slower.
const state=Symbol('food lifecycle'),standard=new Set(['id','x','y','size','kind','value','createdAt']);
class IndexedFood{
  constructor(data){
    this[state]={source:data.source,expiresAt:data.expiresAt,kind:data.kind,value:data.value,owner:null,entry:null};
    this.id=data.id;this.x=data.x;this.y=data.y;this.size=data.size;this.createdAt=data.createdAt;
    for(const key in data)if(!standard.has(key)&&key!=='source'&&key!=='expiresAt')this[key]=data[key];
  }
  get kind(){return this[state].kind;}
  set kind(value){const s=this[state];s.kind=value;if(s.owner?.index.get(s.entry.id)===s.entry)s.owner.invalidateMetadata(s.entry);}
  get value(){return this[state].value;}
  set value(value){const s=this[state];s.value=value;if(s.owner?.index.get(s.entry.id)===s.entry)s.owner.invalidateMetadata(s.entry);}
  get source(){return this[state].source;}
  set source(value){const s=this[state];s.source=value;if(s.owner?.index.get(s.entry.id)===s.entry)s.owner.updateSource(s.entry,value);}
  get expiresAt(){return this[state].expiresAt;}
  set expiresAt(value){const s=this[state];s.expiresAt=value;if(s.owner?.index.get(s.entry.id)===s.entry){s.entry.expiresAt=value;s.owner.updateExpiry(s.entry);}}
  toJSON(){
    const out={id:this.id,x:this.x,y:this.y,size:this.size,kind:this.kind,value:this.value,createdAt:this.createdAt,expiresAt:this.expiresAt};
    if(this.source!==undefined)out.source=this.source;
    for(const key of Object.keys(this))if(!standard.has(key))out[key]=this[key];
    return out;
  }
}
function bindFood(food,owner,entry){
  if(!(food instanceof IndexedFood))return false;
  const s=food[state];s.owner=owner;s.entry=entry;return true;
}
module.exports={IndexedFood,bindFood};
