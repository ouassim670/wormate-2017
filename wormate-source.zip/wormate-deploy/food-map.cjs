// Index static food positions while preserving Map insertion order in both
// network queries and simulation tick snapshots, including overlapping food.
const pickupKey=(x,y)=>x>=-32768&&x<32768&&y>=-32768&&y<32768?(x+32768)*65536+y+32768:x+','+y;
const {IndexedFood,bindFood}=require('./food-lifecycle.cjs');
class FoodMap extends Map {
  constructor({lifecycle=false}={}){super();this.cells=new Map();this.index=new Map();this.sequence=0;this.orderedCells=null;this.pickupCells=new Map();this.queryGrid=new Map();this.dirtyCells=new Set();this.lifecycle=lifecycle;this.expiryHeap=[];this.deathEntries=new Set();this.deathCache=null;this.externalEntries=new Set();}
  create(data){return this.lifecycle?new IndexedFood(data):data;}
  swapExpiry(a,b){const heap=this.expiryHeap,temp=heap[a];heap[a]=heap[b];heap[b]=temp;heap[a].heapIndex=a;heap[b].heapIndex=b;}
  updateExpiry(entry){
    const heap=this.expiryHeap;entry.when=Number(entry.expiresAt);if(Number.isNaN(entry.when)||entry.when===Infinity){this.removeExpiry(entry);return;}
    let at=entry.heapIndex;if(at<0){at=heap.length;heap.push(entry);entry.heapIndex=at;}
    while(at>0){const parent=(at-1)>>1;if(heap[parent].when<=entry.when)break;this.swapExpiry(at,parent);at=parent;}
    for(;;){let child=at*2+1;if(child>=heap.length)break;if(child+1<heap.length&&heap[child+1].when<heap[child].when)child++;if(heap[at].when<=heap[child].when)break;this.swapExpiry(at,child);at=child;}
  }
  removeExpiry(entry){
    const heap=this.expiryHeap,at=entry.heapIndex;if(at<0)return;const last=heap.pop();entry.heapIndex=-1;
    if(at<heap.length){heap[at]=last;last.heapIndex=at;this.updateExpiry(last);}
  }
  invalidateMetadata(entry){entry.cell.foods=null;this.dirtyCells.add(entry.cell.key);}
  updateSource(entry,source){entry.source=source;if(source==='death')this.deathEntries.add(entry);else this.deathEntries.delete(entry);this.deathCache=null;this.invalidateMetadata(entry);}
  syncExternal(){for(const entry of this.externalEntries){if(entry.expiresAt!==entry.food.expiresAt){entry.expiresAt=entry.food.expiresAt;this.updateExpiry(entry);}if(entry.source!==entry.food.source)this.updateSource(entry,entry.food.source);if(entry.lastKind!==entry.food.kind||entry.lastValue!==entry.food.value){entry.lastKind=entry.food.kind;entry.lastValue=entry.food.value;this.invalidateMetadata(entry);}}}
  expire(time){
    if(!this.lifecycle){for(const f of this.values())if(f.expiresAt<=time)this.delete(f.id);return;}
    this.syncExternal();while(this.expiryHeap.length&&this.expiryHeap[0].when<=time)this.delete(this.expiryHeap[0].id);
  }
  deathSnapshot(){
    if(!this.lifecycle)return [...this.values()].filter(f=>f.source==='death');
    this.syncExternal();return this.deathCache||=([...this.deathEntries].sort((a,b)=>a.order-b.order).map(e=>e.food));
  }
  set(id,food){
    const old=this.index.get(id),order=old?old.order:this.sequence++;
    if(old)this.removeIndex(old);
    const gx=Math.floor(food.x/16),gy=Math.floor(food.y/16),key=`${gx},${gy}`;
    this.dirtyCells.add(key);
    let cell=this.cells.get(key);
    if(!cell){this.cells.set(key,cell={gx,gy,key,items:new Set(),minOrder:order,lastOrder:order,ordered:true});this.orderedCells=null;}
    if(order<cell.lastOrder)cell.ordered=false;
    if(order<cell.minOrder)this.orderedCells=null;
    cell.minOrder=Math.min(cell.minOrder,order);cell.lastOrder=Math.max(cell.lastOrder,order);
    const fineKey=pickupKey(Math.floor(food.x/2),Math.floor(food.y/2));
    let pickup=this.pickupCells.get(fineKey);if(!pickup)this.pickupCells.set(fineKey,pickup=new Set());
    const entry={id,food,order,cell,pickup,pickupKey:fineKey};pickup.add(entry);cell.items.add(entry);cell.foods=null;this.index.set(id,entry);
    if(this.lifecycle){entry.expiresAt=food.expiresAt;entry.source=food.source;entry.heapIndex=-1;if(!bindFood(food,this,entry))this.externalEntries.add(entry);this.updateExpiry(entry);if(entry.source==='death'){this.deathEntries.add(entry);this.deathCache=null;}}
    super.set(id,food);return this;
  }
  removeIndex(entry){
    if(this.lifecycle){this.removeExpiry(entry);this.externalEntries.delete(entry);if(this.deathEntries.delete(entry))this.deathCache=null;}
    this.dirtyCells.add(entry.cell.key);
    entry.pickup.delete(entry);if(!entry.pickup.size)this.pickupCells.delete(entry.pickupKey);
    const cell=entry.cell;cell.items.delete(entry);cell.foods=null;
    if(!cell.items.size){this.cells.delete(cell.key);this.orderedCells=null;}
    // Removing an old stacked food trail can delete thousands of successive
    // minima from one cell. Recompute its minimum only if global ordering is
    // requested, rather than scanning the entire pile after every deletion.
    else if(entry.order===cell.minOrder){cell.minOrder=Infinity;cell.minDirty=true;this.orderedCells=null;}
    this.index.delete(entry.id);
  }
  delete(id){const entry=this.index.get(id);if(entry)this.removeIndex(entry);return super.delete(id);}
  clear(){super.clear();this.cells.clear();this.index.clear();this.pickupCells.clear();this.queryGrid.clear();this.dirtyCells.clear();this.sequence=0;this.orderedCells=null;this.expiryHeap.length=0;this.deathEntries.clear();this.deathCache=null;this.externalEntries.clear();}
  snapshotQueryGrid(){
    // Direct cell lookups do not need the globally sorted Map. Update only
    // changed cell arrays; mutations later in the tick leave this snapshot alone.
    for(const key of this.dirtyCells){
      const cell=this.cells.get(key);
      if(!cell){this.queryGrid.delete(key);continue;}
      if(!cell.foods){const entries=[...cell.items];if(!cell.ordered)entries.sort((a,b)=>a.order-b.order);cell.foods=entries.map(e=>e.food);}
      this.queryGrid.set(key,cell.foods);
    }
    this.dirtyCells.clear();return this.queryGrid;
  }
  queryPickups(x,y,initialReach,maxReach){
    const minX=Math.floor((x-initialReach)/16),maxX=Math.floor((x+initialReach)/16),minY=Math.floor((y-initialReach)/16),maxY=Math.floor((y+initialReach)/16),entries=[];
    for(let gx=Math.floor((x-maxReach)/2);gx<=Math.floor((x+maxReach)/2);gx++)for(let gy=Math.floor((y-maxReach)/2);gy<=Math.floor((y+maxReach)/2);gy++){
      const cell=this.pickupCells.get(pickupKey(gx,gy));if(!cell)continue;
      for(const entry of cell){const coarse=entry.cell;
        if(coarse.gx>=minX&&coarse.gx<=maxX&&coarse.gy>=minY&&coarse.gy<=maxY)entries.push(entry);
      }
    }
    entries.sort((a,b)=>a.cell.gx-b.cell.gx||a.cell.gy-b.cell.gy||a.order-b.order);
    return entries.map(e=>e.food);
  }
  snapshotGrid(){
    if(!this.orderedCells)for(const cell of this.cells.values())if(cell.minDirty){cell.minOrder=Infinity;for(const entry of cell.items)cell.minOrder=Math.min(cell.minOrder,entry.order);cell.minDirty=false;}
    const cells=this.orderedCells||=( [...this.cells.values()].sort((a,b)=>a.minOrder-b.minOrder));
    return new Map(cells.map(cell=>{
      if(!cell.foods){const entries=[...cell.items];if(!cell.ordered)entries.sort((a,b)=>a.order-b.order);cell.foods=entries.map(entry=>entry.food);}
      return [cell.key,cell.foods];
    }));
  }
  querySquare(x,y,reach,known){
    const minX=Math.floor((x-reach)/16),maxX=Math.floor((x+reach)/16),minY=Math.floor((y-reach)/16),maxY=Math.floor((y+reach)/16);
    const inside=f=>Math.abs(f.x-x)<reach&&Math.abs(f.y-y)<reach&&(!known||!known.has(f.id));
    if((maxX-minX+1)*(maxY-minY+1)>this.cells.size/2)return [...this.values()].filter(inside);
    const entries=[];
    for(let gx=minX;gx<=maxX;gx++)for(let gy=minY;gy<=maxY;gy++){
      const cell=this.cells.get(`${gx},${gy}`);if(cell)for(const entry of cell.items)if(inside(entry.food))entries.push(entry);
    }
    // Preserve Map insertion order, including overlaps and replaced IDs.
    entries.sort((a,b)=>a.order-b.order);return entries.map(entry=>entry.food);
  }
}
module.exports={FoodMap};
