const { visibleSpine } = require("./geometry.cjs");
// Sample the body that was actually drawn, rather than every second coarse
// control point. Keep a segment's share even when it overlaps its neighbours:
// rapid growth leaves a food pile at the stacked tail, not an even thin trail.
function deathFoodPositions(w, radius, random) {
  const spine = visibleSpine(w.body),
    edges = [];
  let length = 0;
  for (let i = 1; i < spine.length; i++) {
    const a = spine[i - 1],
      b = spine[i],
      distance = Math.hypot(b.x - a.x, b.y - a.y);
    const weight = Math.max(distance, radius * 0.5);
    edges.push({ a, b, start: length, length: distance, weight });
    length += weight;
  }
  const lanes = Math.min(4, Math.max(2, Math.ceil(radius * 2)));
  const count = Math.min(
    1000,
    Math.max(6, Math.ceil((length / Math.max(0.3, radius * 0.5)) * lanes * .65)),
  );
  const positions = [];
  let edgeIndex = 0;
  for (let i = 0; i < count; i++) {
    if (!edges.length) {
      const angle = i * 2.399963229728653,
        r = radius * Math.sqrt((i + 0.5) / count);
      positions.push({
        x: w.x + Math.cos(angle) * r,
        y: w.y + Math.sin(angle) * r,
      });
      continue;
    }
    const distance = ((i + 0.5) / count) * length;
    while (
      edgeIndex < edges.length - 1 &&
      distance > edges[edgeIndex].start + edges[edgeIndex].weight
    )
      edgeIndex++;
    const edge = edges[edgeIndex],
      t = (distance - edge.start) / edge.weight;
    if (edge.length < radius * 0.05) {
      // Give coincident body samples distinct food positions within the body
      // width. The packed food IDs must survive coordinate quantization.
      const angle = i * 2.399963229728653,
        spread = radius * 0.85 * Math.sqrt(random());
      positions.push({
        x: edge.a.x + (edge.b.x - edge.a.x) * t + Math.cos(angle) * spread,
        y: edge.a.y + (edge.b.y - edge.a.y) * t + Math.sin(angle) * spread,
      });
      continue;
    }
    const dx = (edge.b.x - edge.a.x) / edge.length,
      dy = (edge.b.y - edge.a.y) / edge.length;
    const across = (random() - 0.5) * radius * 1.8;
    const along = (random() - 0.5) * Math.min(0.4, length / count) * 0.7;
    positions.push({
      x: edge.a.x + (edge.b.x - edge.a.x) * t - dy * across + dx * along,
      y: edge.a.y + (edge.b.y - edge.a.y) * t + dx * across + dy * along,
    });
  }
  return positions;
}
module.exports = { deathFoodPositions };
