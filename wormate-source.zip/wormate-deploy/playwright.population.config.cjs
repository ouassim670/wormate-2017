const {defineConfig}=require('@playwright/test');
module.exports=defineConfig({testDir:'./tests',testMatch:'population-render.population.cjs',timeout:120000,workers:1,
  use:{baseURL:'http://127.0.0.1:3107',browserName:'chromium',channel:'chrome',viewport:{width:1280,height:800}},
  webServer:{command:'node tests/population-render-server.cjs',url:'http://127.0.0.1:3107',reuseExistingServer:false}});
