const {parentPort,workerData}=require('node:worker_threads');
const {createBotScores}=require('./bot-scores.cjs');
const store=createBotScores(workerData.file,{backup:workerData.backup,onError:()=>{}});
parentPort.on('message',message=>{
  try{
    if(message.full)store.records.clear();
    for(const row of message.rows)store.records.set(row.name,row);
    store.markDirty();
    parentPort.postMessage({id:message.id,ok:store.flush({checkpoint:message.full})});
  }catch(error){parentPort.postMessage({id:message.id,ok:false,error:error.code||error.message});}
});
