const {Worker,isMainThread,parentPort}=require('node:worker_threads');
const {minimapPacket}=require('./minimap.cjs');
const {shape:dimensions}=require('./simulation.cjs');
if(!isMainThread){
  parentPort.on('message',({worms,radius})=>{
    const packet=minimapPacket(worms,radius,dimensions);
    parentPort.postMessage(packet,[packet.buffer]);
  });
}
function createMinimapWorker(onPacket=()=>{}){
  const worker=new Worker(__filename);worker.unref();
  const service={latest:null,busy:false,failed:false,closed:false,
    request(worms,radius){
      if(service.busy||service.failed||service.closed)return;
      service.busy=true;
      worker.postMessage({radius,worms:[...worms].map(w=>({mass:w.mass,body:w.body}))});
    },
    close(){service.closed=true;return worker.terminate();},
  };
  worker.on('message',data=>{service.busy=false;service.latest=Buffer.from(data);onPacket(service.latest);});
  worker.on('error',()=>{service.failed=true;service.busy=false;});
  worker.on('exit',()=>{if(!service.closed){service.failed=true;service.busy=false;}});
  worker.unref();
  return service;
}
module.exports={createMinimapWorker};
