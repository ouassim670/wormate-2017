const fs=require('node:fs'),path=require('node:path');
function createProfileResets(file){
  const epochs=fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8')):{allProfiles:0,leaders:0};
  return {epochs,reset(scope){
    if(!['allProfiles','leaders'].includes(scope))throw Error('Invalid reset scope.');
    epochs[scope]=Math.max(Date.now(),(epochs[scope]||0)+1);
    fs.mkdirSync(path.dirname(file),{recursive:true});
    fs.writeFileSync(file+'.tmp',JSON.stringify(epochs));fs.renameSync(file+'.tmp',file);
  }};
}
module.exports={createProfileResets};
