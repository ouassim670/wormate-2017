// Conservative broad phase: exact collision/collection rules still decide hits.
// Integer keys avoid allocating a string for every populated/query cell.
// Keep an exact string fallback for coordinates outside the packed range.
const cellKey=(x,y)=>x>=-32768&&x<32768&&y>=-32768&&y<32768?(x+32768)*65536+y+32768:x+','+y;
class SpatialGrid {
  constructor(cellSize = 12) { this.cellSize = cellSize; this.cells = new Map(); this.global = []; this.all = []; this.seen=[];this.stamp=0; }
  insert(index, box, padding = 0) {
    this.all.push(index);
    const s = this.cellSize;
    const x0 = Math.floor((box.minX - padding) / s), x1 = Math.floor((box.maxX + padding) / s);
    const y0 = Math.floor((box.minY - padding) / s), y1 = Math.floor((box.maxY + padding) / s);
    if (!Number.isFinite(x0 + x1 + y0 + y1) || (x1 - x0 + 1) * (y1 - y0 + 1) > 4096) { this.global.push(index); return; }
    for (let x = x0; x <= x1; x++) for (let y = y0; y <= y1; y++) {
      const key = cellKey(x,y);
      let cell = this.cells.get(key);
      if (!cell) this.cells.set(key, cell = []);
      if(cell[cell.length-1]!==index)cell.push(index);
    }
  }
  query(box, padding = 0) {
    return this.queryInto(box,padding,[]);
  }
  queryInto(box,padding,found){
    found.length=0;const stamp=++this.stamp,seen=this.seen;
    const s = this.cellSize;
    const x0 = Math.floor((box.minX - padding) / s), x1 = Math.floor((box.maxX + padding) / s);
    const y0 = Math.floor((box.minY - padding) / s), y1 = Math.floor((box.maxY + padding) / s);
    const add=index=>{if(seen[index]!==stamp){seen[index]=stamp;found.push(index);}};
    if (!Number.isFinite(x0 + x1 + y0 + y1) || (x1 - x0 + 1) * (y1 - y0 + 1) > 4096){for(const index of this.all)add(index);return found.sort((a,b)=>a-b);}
    for(const index of this.global)add(index);
    for (let x = x0; x <= x1; x++) for (let y = y0; y <= y1; y++) {
      const cell = this.cells.get(cellKey(x,y));
      if (cell) for (const index of cell) add(index);
    }
    return found.sort((a,b)=>a-b);
  }
}
module.exports = { SpatialGrid };
