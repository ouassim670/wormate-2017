const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {isLocalAdmin}=require('./local-access.cjs');
const COOKIE='wormate_admin';
function createAdminAccess(file,{now=Date.now}={}){
  fs.mkdirSync(path.dirname(file),{recursive:true});
  if(!fs.existsSync(file))fs.writeFileSync(file,crypto.randomBytes(32).toString('base64url')+'\n',{flag:'wx',mode:0o600});
  const key=fs.readFileSync(file,'utf8').trim();
  if(key.length<32)throw new Error('Admin key must contain at least 32 characters.');
  const digest=value=>crypto.createHash('sha256').update(value).digest();
  const sign=value=>crypto.createHmac('sha256',key).update(value).digest('base64url');
  const equal=(a,b)=>crypto.timingSafeEqual(digest(a),digest(b));
  const issue=()=>{const body=`${now()+86400000}.${crypto.randomBytes(24).toString('base64url')}`;return `${body}.${sign(body)}`;};
  function valid(token){
    if(typeof token!=='string'||token.length>200)return false;
    const parts=token.split('.');
    if(parts.length!==3||!/^\d+$/.test(parts[0]))return false;
    const expires=Number(parts[0]);
    return expires>now()&&expires<=now()+86400000&&equal(parts[2],sign(parts.slice(0,2).join('.')));
  }
  const cookie=req=>String(req.headers.cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith(COOKIE+'='))?.slice(COOKIE.length+1);
  function access(req){
    const token=cookie(req);
    return {admin:isLocalAdmin(req)||valid(token),adminToken:valid(token)?token:undefined};
  }
  const failures=new Map();
  const json=(res,status,body,headers={})=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store',...headers});res.end(JSON.stringify(body));};
  function handle(req,res,url){
    if(url.pathname==='/api/access'){json(res,200,access(req));return true;}
    if(url.pathname!=='/api/admin/login')return false;
    if(req.method!=='POST'){json(res,405,{error:'Use POST.'},{Allow:'POST'});return true;}
    if(!/^application\/json(?:;|$)/i.test(req.headers['content-type']||'')){json(res,415,{error:'Use JSON.'});return true;}
    const address=req.socket.remoteAddress;
    const previous=failures.get(address);
    if(previous&&previous.until>now()&&previous.count>=10){json(res,429,{error:'Too many attempts. Try again in ten minutes.'});return true;}
    let body='',oversize=false;
    req.on('data',chunk=>{if(oversize)return;body+=chunk;if(Buffer.byteLength(body)>1024){oversize=true;json(res,413,{error:'Request too large.'});}});
    req.on('end',()=>{
      if(oversize)return;
      let candidate;try{candidate=JSON.parse(body).key;}catch{}
      if(typeof candidate!=='string'||!equal(candidate,key)){
        if(failures.size>=256)failures.clear();
        failures.set(address,{count:previous&&previous.until>now()?previous.count+1:1,until:now()+600000});
        return json(res,401,{error:'Incorrect admin key.'});
      }
      failures.delete(address);
      const token=issue();
      const secure=req.socket.encrypted||req.headers['x-forwarded-proto']==='https';
      json(res,200,{admin:true,adminToken:token},{'Set-Cookie':`${COOKIE}=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400${secure?'; Secure':''}`});
    });
    return true;
  }
  return {handle,access,valid};
}
module.exports={createAdminAccess};
