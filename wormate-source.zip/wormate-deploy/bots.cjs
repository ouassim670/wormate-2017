const {BASE_HANDLES:NAMES,botName}=require('./bot-names.cjs');

function initialBotScore(random) {
  const tier=random();
  if(tier<.95) {
    // Most startup worms are fresh or small, even in a 300-bot arena.
    if(random()<.5)return 16;
    return 16+Math.floor(Math.pow(random(),3)*985);
  }
  if(tier<.99)return 1001+Math.floor(random()*9000);
  if(tier<.999)return 10001+Math.floor(random()*40000);
  return 50001+Math.floor(random()*200000);
}

// Learn gradually between 500 and 50,000 score, without changing movement limits.
function botSkill(w) {
  return Math.max(0,Math.min(1,Math.log(Math.max(1,(w.mass||.32)*50/500))/Math.log(100)));
}
function botHeading(w, nearest, time, radius, random) {
  const skill=botSkill(w);
  if(!w.botGoal || time>=w.botGoal.until || Math.hypot(w.x-w.botGoal.x,w.y-w.botGoal.y)<8) {
    const goalRadius=random()<.9?radius*.42:radius-6;
    const angle=random()*Math.PI*2, distance=goalRadius*Math.sqrt(random());
    w.botGoal={x:Math.cos(angle)*distance,y:Math.sin(angle)*distance,until:time+8+random()*22,phase:random()*Math.PI*2,foodInterest:0.2+random()*0.9};
  }
  const goal=Math.atan2(w.botGoal.y-w.y,w.botGoal.x-w.x);
  // Prefer central destinations while retaining occasional outer trips.
  let x=Math.cos(goal),y=Math.sin(goal);
  if(nearest) {
    const valuable=nearest.source==='death'||(nearest.kind>=84&&nearest.kind<=86);
    const forage=Math.atan2(nearest.y-w.y,nearest.x-w.x),weight=valuable?2+skill*.6:2.2+skill*.6+w.botGoal.foodInterest*.2;
    x+=Math.cos(forage)*weight;y+=Math.sin(forage)*weight;
  }
  const wander=w.botGoal.phase+time*0.23;
  const wandering=.22-.12*skill;
  x+=Math.cos(wander)*wandering;y+=Math.sin(wander)*wandering;
  const distance=Math.hypot(w.x,w.y);
  if(distance>radius*.45){const pull=.6*(distance/radius);x-=w.x/distance*pull;y-=w.y/distance*pull;}
  return Math.atan2(y,x);
}
function botFoodPriority(f,w,skill=w?botSkill(w):1){
  return f.source==='death'?2+skill*(6+Math.min(2,Math.log1p(Math.max(0,f.value||0)))):
    f.kind>=84&&f.kind<=86?2+8*skill:f.kind===87?3+5*skill:f.kind>=81&&f.kind<=88?1.5+skill:w?4-3*skill:4;
}
function botFoodScore(w,f){
  return botFoodPriority(f,w)/(4+Math.hypot(f.x-w.x,f.y-w.y));
}
function botBoost(w,time,balance,random) {
  if(w.botBoostAt===undefined)w.botBoostAt=time+2+random()*4;
  if(time<(w.botBoostUntil||0))return w.mass>balance.boostFloor;
  if(time<w.botBoostAt)return false;
  // Occasional imperfect sprints, not instant escapes or continuous chasing.
  const duration=.35+random()*.65;
  w.botBoostAt=time+duration+5+random()*7;
  if(w.mass<=balance.boostFloor+balance.boostLossPerSecond*.4)return false;
  w.botBoostUntil=time+duration;
  return true;
}
module.exports={NAMES,botName,botHeading,botBoost,botFoodScore,botFoodPriority,botSkill,initialBotScore};
