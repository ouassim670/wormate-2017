Wormate 2017 - hosted deployment bundle

This bundle is prepared for a Node.js web service that supports WebSockets.
It excludes the original .data admin keys, saved bot scores, .git history,
node_modules, local runtime logs, and development tests.

Build command: npm install
Start command: npm start
The service listens on the PORT environment variable and binds to 0.0.0.0.

Deploy as a Web Service (not a static site) on a host that supports WebSockets.
The game uses an in-memory arena; saved bot/profile data may not persist on
hosts with ephemeral filesystems or when an instance restarts. Free hosts may
sleep when idle, causing a short startup delay on the next visit.

This is a community/local restoration, not the original Wormate.io service.
